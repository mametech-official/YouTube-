package com.vancedplayer.app.ui.player

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.runtime.key
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.WatchLater
import androidx.compose.material.icons.outlined.WatchLater
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import android.widget.Toast
import androidx.compose.runtime.rememberCoroutineScope
import com.vancedplayer.app.VancedPlayerApp
import com.vancedplayer.app.auth.GoogleAuth
import com.vancedplayer.app.data.model.VideoComment
import com.vancedplayer.app.data.remote.YouTubeApi
import com.vancedplayer.app.util.CrashLogger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import com.vancedplayer.app.data.VideoCatalog
import com.vancedplayer.app.data.prefs.ResumeLogic
import kotlinx.coroutines.delay
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vancedplayer.app.data.model.Video
import com.vancedplayer.app.ui.components.ChannelAvatar
import com.vancedplayer.app.ui.components.SubscribeButton
import com.vancedplayer.app.ui.components.VideoCard
import com.vancedplayer.app.ui.theme.VpColors
import com.vancedplayer.app.util.Formatters

private val speedOptions = listOf(
    PlayerConstants.PlaybackRate.RATE_0_25 to "0,25x",
    PlayerConstants.PlaybackRate.RATE_0_5 to "0,5x",
    PlayerConstants.PlaybackRate.RATE_1 to "Normal",
    PlayerConstants.PlaybackRate.RATE_1_5 to "1,5x",
    PlayerConstants.PlaybackRate.RATE_2 to "2x"
)

private fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/** Mini oynatıcının boyutu (16:9). */
private val MiniWidth = 114.dp
private val MiniHeight = 64.dp

/**
 * Uygulama genelindeki oynatıcı durumu. Oynatıcı bir sayfa değil, tüm ekranların üstünde duran tek bir
 * bileşendir; bu yüzden sen gezinirken küçülüp (mini oynatıcı) çalmaya devam edebilir.
 */
class PlayerHostState {
    var videoId by mutableStateOf<String?>(null)
        private set
    var expanded by mutableStateOf(false)
        private set
    var controller by mutableStateOf<PlayerController?>(null)

    fun open(id: String) {
        videoId = id
        expanded = true
    }

    fun minimize() {
        if (videoId != null) expanded = false
    }

    fun expand() {
        if (videoId != null) expanded = true
    }

    fun close() {
        videoId = null
        expanded = false
    }
}

/** Alt çubuğun hemen üstünde görünen mini oynatıcı çubuğu (video görüntüsü [PlayerHost] tarafından üstüne çizilir). */
@Composable
fun MiniPlayerBar(host: PlayerHostState) {
    val id = host.videoId ?: return
    val video = remember(id) { VideoCatalog.get(id) }
    val controller = host.controller
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(MiniHeight)
            .background(VpColors.Card)
            .clickable { host.expand() },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Spacer(Modifier.width(MiniWidth))
        Column(modifier = Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text(
                text = video?.title ?: "Video",
                color = VpColors.TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            if (video != null) {
                Text(
                    text = video.channelName,
                    color = VpColors.TextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        IconButton(onClick = { controller?.togglePlay() }) {
            Icon(
                if (controller?.isPlaying == true) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = if (controller?.isPlaying == true) "Duraklat" else "Oynat",
                tint = VpColors.TextPrimary
            )
        }
        IconButton(onClick = { host.close() }) {
            Icon(Icons.Filled.Close, contentDescription = "Oynatıcıyı kapat", tint = VpColors.TextPrimary)
        }
    }
}

/**
 * Tüm ekranların üstüne yerleştirilir. Tam ekran, mini ve küçük pencere (PiP) düzenleri arasında
 * oynatıcı görünümü yeniden oluşturulmadan geçer (videoyu kesmez).
 */
@Composable
fun PlayerHost(host: PlayerHostState, navBarHeight: Dp, onOpenChannel: (String) -> Unit) {
    val id = host.videoId
    if (id != null) {
        key(id) { PlayerHostContent(host, id, navBarHeight, onOpenChannel) }
    }
}

@Composable
private fun PlayerHostContent(
    host: PlayerHostState,
    videoId: String,
    navBarHeight: Dp,
    onOpenChannel: (String) -> Unit
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val pip = LocalPipMode.current
    val expanded = host.expanded
    val fullscreen = expanded && landscape && !pip
    val controller = remember { PlayerController() }
    var locked by rememberSaveable { mutableStateOf(false) }
    val video = remember(videoId) { VideoCatalog.get(videoId) }
    val related = remember(videoId) { VideoCatalog.related(videoId, 12) }
    val vm: PlayerViewModel = viewModel()
    val isFavorite by remember(videoId) { vm.isFavorite(videoId) }.collectAsState(initial = false)
    val isLater by remember(videoId) { vm.isWatchLater(videoId) }.collectAsState(initial = false)
    val channelId = video?.channelId.orEmpty()
    val isSubscribed by remember(channelId) { vm.isSubscribed(channelId) }.collectAsState(initial = false)
    var recorded by remember(videoId) { mutableStateOf(false) }
    val container = remember(context) { (context.applicationContext as VancedPlayerApp).container }
    val prefs = container.prefs
    val backgroundPlay = remember { prefs.backgroundPlay }
    val positions = container.positions
    val startSecond = remember(videoId) { ResumeLogic.startPosition(positions.get(videoId), 0f) }
    val scope = rememberCoroutineScope()
    var liked by remember(videoId) { mutableStateOf(false) }
    val apiKey = if (prefs.forceSample) "" else prefs.apiKey

    val onLike: () -> Unit = {
        if (!prefs.googleSignedIn) {
            Toast.makeText(context, "Beğenmek için Hesap sekmesinden Google ile giriş yapın.", Toast.LENGTH_LONG).show()
        } else {
            scope.launch {
                try {
                    val token = GoogleAuth.token(context)
                    if (token == null) {
                        Toast.makeText(context, "Oturum süresi doldu. Hesap sekmesinden tekrar giriş yapın.", Toast.LENGTH_LONG).show()
                    } else {
                        YouTubeApi.rate(token, videoId, if (liked) "none" else "like")
                        liked = !liked
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    CrashLogger.logHandled("Beğeni gönderilemedi", e)
                    Toast.makeText(context, e.message ?: "Beğeni gönderilemedi", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
    val onShare: () -> Unit = {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, "https://youtu.be/$videoId")
        context.startActivity(Intent.createChooser(send, "Paylaş"))
    }

    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (backgroundPlay && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    DisposableEffect(controller) {
        host.controller = controller
        onDispose { if (host.controller === controller) host.controller = null }
    }

    val saveProgress: () -> Unit = {
        val s = controller.currentSecond
        if (ResumeLogic.shouldClear(s, controller.duration, controller.ended)) {
            positions.clear(videoId)
        } else if (s >= ResumeLogic.MIN_SECONDS) {
            positions.save(videoId, s)
        }
    }
    LaunchedEffect(videoId) {
        if (startSecond > 0f) {
            Toast.makeText(context, "Kaldığın yerden devam: " + Formatters.duration(startSecond.toInt()), Toast.LENGTH_SHORT).show()
        }
    }
    DisposableEffect(Unit) {
        PlaybackSession.playerVisible = true
        PlaybackSession.title = video?.title ?: "Video"
        PlaybackSession.onToggle = { controller.togglePlay() }
        PlaybackSession.onClose = { host.close() }
        var lastSave = 0L
        controller.onProgress = {
            val now = System.currentTimeMillis()
            if (now - lastSave > 5_000L) {
                lastSave = now
                saveProgress()
            }
        }
        controller.onPlaybackChanged = { playing ->
            PlaybackSession.playing = playing
            if (backgroundPlay) {
                if (playing && !PlaybackService.running) {
                    PlaybackService.start(context)
                } else {
                    PlaybackService.update(context)
                }
            }
        }
        onDispose {
            controller.onProgress = null
            controller.onPlaybackChanged = null
            saveProgress()
            positions.trim()
            PlaybackSession.reset()
            PlaybackService.stop(context)
        }
    }

    LaunchedEffect(controller.isPlaying) {
        if (controller.isPlaying && !recorded && video != null) {
            recorded = true
            vm.recordHistory(video)
        }
    }

    // Yatay tam ekranda sistem çubuklarını gizle.
    DisposableEffect(fullscreen) {
        val window = activity?.window
        val insets = window?.let { WindowInsetsControllerCompat(it, it.decorView) }
        if (fullscreen) {
            insets?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            insets?.hide(WindowInsetsCompat.Type.systemBars())
        }
        onDispose { insets?.show(WindowInsetsCompat.Type.systemBars()) }
    }
    // Küçülünce veya kapanınca döndürme kilidini bırak.
    LaunchedEffect(expanded) {
        if (!expanded) activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }
    DisposableEffect(Unit) {
        onDispose { activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
    }

    val rotate = {
        activity?.requestedOrientation = if (landscape) {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        }
    }

    BackHandler(enabled = expanded && !pip) {
        if (landscape) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            host.minimize()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .then(if (expanded || pip) Modifier.background(Color.Black) else Modifier)
    ) {
        // Dikey tam ekran: videonun altındaki bilgi, yorum ve önerilen videolar.
        if (expanded && !landscape && !pip) {
            Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
                Spacer(Modifier.fillMaxWidth().aspectRatio(16f / 9f))
                LazyColumn(
                    modifier = Modifier.fillMaxSize().background(VpColors.Black).navigationBarsPadding(),
                    contentPadding = PaddingValues(top = 12.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    item {
                        VideoInfo(
                            liked = liked,
                            onLike = onLike,
                            onShare = onShare,
                            controller = controller,
                            locked = locked,
                            onLock = { locked = true },
                            onRotate = rotate,
                            video = video,
                            isFavorite = isFavorite,
                            isLater = isLater,
                            isSubscribed = isSubscribed,
                            onFavorite = { video?.let { vm.toggleFavorite(it) } },
                            onLater = { video?.let { vm.toggleWatchLater(it) } },
                            onSubscribe = { video?.let { vm.toggleSubscribe(it) } },
                            onChannelClick = { if (channelId.isNotBlank()) onOpenChannel(channelId) }
                        )
                    }
                    if (apiKey.isNotBlank()) {
                        item { CommentsSection(videoId = videoId, apiKey = apiKey) }
                    }
                    if (related.isNotEmpty()) {
                        item {
                            Text(
                                "Önerilen videolar",
                                color = VpColors.TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp)
                            )
                        }
                        items(related, key = { it.id }) { v ->
                            VideoCard(video = v, edgeToEdge = true, onClick = { host.open(v.id) })
                        }
                    }
                }
            }
        }
        // Yatay tam ekran: sağ kenarda kontrol düğmeleri.
        if (fullscreen) {
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .width(72.dp)
                    .background(VpColors.Surface),
                verticalArrangement = Arrangement.SpaceEvenly,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ControlButtons(
                    controller = controller,
                    locked = locked,
                    onLock = { locked = true },
                    onRotate = rotate,
                    onBack = {
                        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                        host.minimize()
                    }
                )
            }
        }

        // OYNATICI: ağaçtaki yeri hiç değişmez; yalnızca boyutu/konumu değişir, böylece video kesilmez.
        PlayerBox(
            modifier = when {
                pip -> Modifier.fillMaxSize()
                fullscreen -> Modifier.fillMaxSize().padding(end = 72.dp)
                expanded -> Modifier
                    .align(Alignment.TopStart)
                    .statusBarsPadding()
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                else -> Modifier
                    .align(Alignment.BottomStart)
                    .padding(bottom = navBarHeight)
                    .size(MiniWidth, MiniHeight)
            },
            videoId = videoId,
            controller = controller,
            locked = locked,
            backgroundPlay = backgroundPlay,
            startSecond = startSecond,
            onUnlock = { locked = false }
        )

        // Dikey tam ekranda küçültme oku.
        if (expanded && !landscape && !pip) {
            IconButton(
                onClick = { host.minimize() },
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .statusBarsPadding()
                    .padding(6.dp)
                    .clip(CircleShape)
                    .background(Color(0x66000000))
            ) {
                Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Küçült", tint = Color.White)
            }
        }
        // Mini modda videoya dokununca tam ekrana dön (video üzerindeki kontroller kapalı).
        if (!expanded && !pip) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(bottom = navBarHeight)
                    .size(MiniWidth, MiniHeight)
                    .clickable { host.expand() }
            )
        }
    }
}

@Composable
private fun PlayerBox(
    modifier: Modifier,
    videoId: String,
    controller: PlayerController,
    locked: Boolean,
    backgroundPlay: Boolean,
    startSecond: Float,
    onUnlock: () -> Unit
) {
    Box(modifier = modifier.background(Color.Black)) {
        YouTubePlayerSurface(
            videoId = videoId,
            controller = controller,
            modifier = Modifier.fillMaxSize(),
            backgroundPlay = backgroundPlay,
            startSecond = startSecond
        )
        controller.errorMessage?.let { message ->
            Box(
                modifier = Modifier.fillMaxSize().background(Color(0xE6000000)).padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(message, color = Color.White, fontSize = 14.sp, textAlign = TextAlign.Center)
            }
        }
        if (locked) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {}
                    )
            )
            IconButton(
                onClick = onUnlock,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .clip(CircleShape)
                    .background(Color(0x99000000))
            ) {
                Icon(Icons.Filled.LockOpen, contentDescription = "Ekran kilidini aç", tint = Color.White)
            }
        }
    }
}

@Composable
private fun ControlButtons(
    controller: PlayerController,
    locked: Boolean,
    onLock: () -> Unit,
    onRotate: () -> Unit,
    onBack: () -> Unit
) {
    var speedMenu by remember { mutableStateOf(false) }
    val enabled = !locked
    IconButton(onClick = onBack) {
        Icon(Icons.Filled.ArrowBack, contentDescription = "Geri", tint = VpColors.TextPrimary)
    }
    IconButton(onClick = { controller.seekBy(-10f) }, enabled = enabled) {
        Icon(Icons.Filled.Replay10, contentDescription = "10 sn geri", tint = VpColors.TextPrimary)
    }
    IconButton(onClick = { controller.togglePlay() }, enabled = enabled) {
        Icon(
            if (controller.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
            contentDescription = if (controller.isPlaying) "Duraklat" else "Oynat",
            tint = VpColors.TextPrimary
        )
    }
    IconButton(onClick = { controller.seekBy(10f) }, enabled = enabled) {
        Icon(Icons.Filled.Forward10, contentDescription = "10 sn ileri", tint = VpColors.TextPrimary)
    }
    Box {
        IconButton(onClick = { speedMenu = true }, enabled = enabled) {
            Icon(
                Icons.Filled.Speed,
                contentDescription = "Oynatma hızı",
                tint = if (controller.speed == PlayerConstants.PlaybackRate.RATE_1) VpColors.TextPrimary else VpColors.Blue
            )
        }
        DropdownMenu(expanded = speedMenu, onDismissRequest = { speedMenu = false }) {
            speedOptions.forEach { (rate, label) ->
                DropdownMenuItem(
                    text = { Text(label) },
                    onClick = {
                        controller.changeSpeed(rate)
                        speedMenu = false
                    }
                )
            }
        }
    }
    IconButton(onClick = onLock, enabled = enabled) {
        Icon(Icons.Filled.Lock, contentDescription = "Ekranı kilitle", tint = VpColors.TextPrimary)
    }
    IconButton(onClick = onRotate, enabled = enabled) {
        Icon(Icons.Filled.ScreenRotation, contentDescription = "Ekranı döndür", tint = VpColors.TextPrimary)
    }
}

@Composable
private fun VideoInfo(
    liked: Boolean,
    onLike: () -> Unit,
    onShare: () -> Unit,
    controller: PlayerController,
    locked: Boolean,
    onLock: () -> Unit,
    onRotate: () -> Unit,
    video: Video?,
    isFavorite: Boolean,
    isLater: Boolean,
    isSubscribed: Boolean,
    onFavorite: () -> Unit,
    onLater: () -> Unit,
    onSubscribe: () -> Unit,
    onChannelClick: () -> Unit
) {
    val now = remember { System.currentTimeMillis() }
    Column {
        Text(
            text = video?.title ?: "Video",
            color = VpColors.TextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 12.dp)
        )
        if (video != null) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = Formatters.views(video.views) + " · " + Formatters.relative(video.publishedAt, now),
                color = VpColors.TextSecondary,
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 12.dp)
            )
            Spacer(Modifier.height(14.dp))
            Row(
                modifier = Modifier.padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ChannelAvatar(video.channelName, modifier = Modifier.clickable(onClick = onChannelClick))
                Spacer(Modifier.width(12.dp))
                Text(
                    text = video.channelName,
                    color = VpColors.TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f).clickable(onClick = onChannelClick)
                )
                SubscribeButton(subscribed = isSubscribed, onClick = onSubscribe)
            }
            Spacer(Modifier.height(14.dp))
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ActionPill(
                    icon = if (liked) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                    label = if (liked) "Beğendin" else "Beğen",
                    active = liked,
                    onClick = onLike
                )
                ActionPill(
                    icon = Icons.Filled.Share,
                    label = "Paylaş",
                    active = false,
                    onClick = onShare
                )
                ActionPill(
                    icon = if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    label = if (isFavorite) "Favoride" else "Favori",
                    active = isFavorite,
                    onClick = onFavorite
                )
                ActionPill(
                    icon = if (isLater) Icons.Filled.WatchLater else Icons.Outlined.WatchLater,
                    label = if (isLater) "Listede" else "Sonra izle",
                    active = isLater,
                    onClick = onLater
                )
                SpeedPill(controller, enabled = !locked)
                ActionPill(
                    icon = Icons.Filled.Lock,
                    label = "Kilitle",
                    active = false,
                    onClick = { if (!locked) onLock() }
                )
                ActionPill(
                    icon = Icons.Filled.ScreenRotation,
                    label = "Döndür",
                    active = false,
                    onClick = { if (!locked) onRotate() }
                )
            }
        }
    }
}

@Composable
private fun ActionPill(icon: ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (active) Color.White else VpColors.Card)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = if (active) Color.Black else VpColors.TextPrimary)
        Spacer(Modifier.width(8.dp))
        Text(label, color = if (active) Color.Black else VpColors.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun SpeedPill(controller: PlayerController, enabled: Boolean) {
    var open by remember { mutableStateOf(false) }
    val label = speedOptions.firstOrNull { it.first == controller.speed }?.second ?: "Normal"
    Box {
        ActionPill(
            icon = Icons.Filled.Speed,
            label = "Hız: $label",
            active = controller.speed != PlayerConstants.PlaybackRate.RATE_1,
            onClick = { if (enabled) open = true }
        )
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            speedOptions.forEach { (rate, text) ->
                DropdownMenuItem(
                    text = { Text(text) },
                    onClick = {
                        controller.changeSpeed(rate)
                        open = false
                    }
                )
            }
        }
    }
}

@Composable
private fun CommentsSection(videoId: String, apiKey: String) {
    var open by remember(videoId) { mutableStateOf(false) }
    var loading by remember(videoId) { mutableStateOf(false) }
    var error by remember(videoId) { mutableStateOf<String?>(null) }
    var comments by remember(videoId) { mutableStateOf<List<VideoComment>>(emptyList()) }

    LaunchedEffect(open) {
        if (open && comments.isEmpty() && !loading) {
            loading = true
            error = null
            try {
                comments = YouTubeApi.comments(apiKey, videoId)
                if (comments.isEmpty()) error = "Henüz yorum yok."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.message ?: "Yorumlar yüklenemedi."
            }
            loading = false
        }
    }

    Column(
        modifier = Modifier
            .padding(horizontal = 12.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(VpColors.Card)
            .clickable { open = !open }
            .padding(12.dp)
    ) {
        Text("Yorumlar", color = VpColors.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        if (!open) {
            Spacer(Modifier.height(4.dp))
            Text("Görmek için dokunun", color = VpColors.TextSecondary, fontSize = 12.sp)
        } else {
            Spacer(Modifier.height(8.dp))
            when {
                loading -> Text("Yükleniyor...", color = VpColors.TextSecondary, fontSize = 13.sp)
                error != null -> Text(error.orEmpty(), color = VpColors.TextSecondary, fontSize = 13.sp)
                else -> comments.forEach { c ->
                    Text(c.author, color = VpColors.TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(c.text, color = VpColors.TextPrimary, fontSize = 13.sp)
                    Text(
                        "${c.likes} beğeni",
                        color = VpColors.TextSecondary,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
    }
}
