package com.vancedplayer.app.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.vancedplayer.app.ui.channel.ChannelScreen
import com.vancedplayer.app.ui.home.HomeScreen
import com.vancedplayer.app.ui.library.LibraryScreen
import com.vancedplayer.app.ui.player.MiniPlayerBar
import com.vancedplayer.app.ui.player.PlayerHost
import com.vancedplayer.app.ui.player.PlayerHostState
import com.vancedplayer.app.ui.search.SearchScreen
import com.vancedplayer.app.ui.settings.SettingsScreen
import com.vancedplayer.app.ui.subscriptions.SubscriptionsScreen
import com.vancedplayer.app.ui.theme.VpColors

private fun NavController.navigateTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun MainScreen() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination

    // Oynatıcı sayfa değil, ekranların üstünde duran tek bir bileşen (mini oynatıcı için).
    val host = remember { PlayerHostState() }
    val density = LocalDensity.current
    var navBarHeight by remember { mutableStateOf(0.dp) }
    val showMini = host.videoId != null && !host.expanded

    val openVideo: (String) -> Unit = { id -> host.open(id) }
    val openChannel: (String) -> Unit = { id ->
        navController.navigate(Routes.channel(id)) { launchSingleTop = true }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                Column {
                    if (showMini) MiniPlayerBar(host)
                    Box(
                        modifier = Modifier.onSizeChanged { size ->
                            navBarHeight = with(density) { size.height.toDp() }
                        }
                    ) {
                        NavigationBar(containerColor = VpColors.Surface) {
                            Screen.bottomItems.forEach { screen ->
                                val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navController.navigateTab(screen.route) },
                                    icon = { Icon(screen.icon, contentDescription = screen.label) },
                                    label = { Text(screen.label, fontSize = 11.sp, maxLines = 1) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color.White,
                                        selectedTextColor = Color.White,
                                        indicatorColor = Color.Transparent,
                                        unselectedIconColor = VpColors.TextSecondary,
                                        unselectedTextColor = VpColors.TextSecondary
                                    )
                                )
                            }
                        }
                    }
                }
            }
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = Routes.HOME,
                modifier = Modifier.padding(innerPadding).statusBarsPadding(),
                enterTransition = { fadeIn(tween(250)) },
                exitTransition = { fadeOut(tween(200)) },
                popEnterTransition = { fadeIn(tween(250)) },
                popExitTransition = { fadeOut(tween(200)) }
            ) {
                composable(Routes.HOME) {
                    HomeScreen(
                        onSearchClick = { navController.navigateTab(Routes.SEARCH) },
                        onProfileClick = { navController.navigateTab(Routes.SETTINGS) },
                        onVideoClick = openVideo,
                        onChannelClick = openChannel
                    )
                }
                composable(
                    route = Routes.CHANNEL_PATTERN,
                    arguments = listOf(navArgument("channelId") { type = NavType.StringType })
                ) { entry ->
                    val channelId = entry.arguments?.getString("channelId").orEmpty()
                    ChannelScreen(
                        channelId = channelId,
                        onBack = { navController.popBackStack() },
                        onVideoClick = openVideo
                    )
                }
                composable(Routes.SEARCH) {
                    SearchScreen(onVideoClick = openVideo, onChannelClick = openChannel)
                }
                composable(Routes.SUBSCRIPTIONS) {
                    SubscriptionsScreen(onVideoClick = openVideo, onChannelClick = openChannel)
                }
                composable(Routes.LIBRARY) {
                    LibraryScreen(onVideoClick = openVideo, onChannelClick = openChannel)
                }
                composable(Routes.SETTINGS) {
                    SettingsScreen()
                }
            }
        }

        PlayerHost(
            host = host,
            navBarHeight = navBarHeight,
            onOpenChannel = { id ->
                host.minimize()
                openChannel(id)
            }
        )
    }
}
