# Vanced Player – Aşama 7 (sürüm 1.1.0)

## Aşama 7'de eklenenler
- Google ile giriş (resmi Google Identity API). Girişten sonra Hesap sekmesinden "YouTube'dan içe aktar": abonelikler ve beğenilen videolar Kütüphane'ye gelir. Oynatıcıda Beğen düğmesi hesabınıza gerçekten beğeni gönderir.
- Oynatıcıda Beğen, Paylaş ve Yorumlar (API anahtarı gerekir).
- Sabit imza anahtarı (`app/debug.keystore`): SHA-1 her derlemede aynı kalır.

## Google girişi kurulumu (bir kez)
1. console.cloud.google.com > projeniz > "OAuth consent screen": Kullanıcı türü Harici, durum Test. "Test users" bölümüne kendi Gmail adresinizi ekleyin.
2. "Credentials" > Create credentials > OAuth client ID > Uygulama türü **Android**.
3. Paket adı: `com.vancedplayer.app`
4. SHA-1: `B8:99:63:56:5F:D2:AB:21:42:1C:EA:C8:45:DA:AC:5C:DD:BC:1E:EF`
5. YouTube Data API v3 zaten etkin olmalı. Uygulamada Hesap > Google ile giriş yap.
Not: "Google bu uygulamayı doğrulamadı" uyarısı çıkarsa Gelişmiş > devam edin (test modunda normaldir).


Kotlin + Jetpack Compose + MVVM + Room. Derleme GitHub Actions ile yapılır (README sonundaki adımlar).

## Aşama 9'da eklenenler
- Uygulama içi mini oynatıcı: oynatıcı artık bir sayfa değil, tüm ekranların üstünde duran tek bir bileşen. Videoyu küçültünce (sol üstteki ok veya Geri) alt çubuğun üstünde mini oynatıcı olarak çalmaya devam eder; sen Ana Sayfa, Ara, Abonelikler, Kütüphane ve kanal sayfalarında gezinirsin. Mini çubukta Oynat/Duraklat ve Kapat var; çubuğa dokununca tam ekrana döner.
- Küçültme, tam ekran, ana ekrana çıkınca küçük pencere (PiP) ve ekran kapanması arasında oynatıcı görünümü yeniden oluşturulmaz (video kesilmez).
- Önerilen videoya tıklayınca tam ekran kalır ve yeni video açılır.
- Alt çubuk: Ana Sayfa, Ara, Abonelikler, Kütüphane, Hesap.

## Aşama 8'de eklenenler
- Abonelikler sekmesi: abone olunan kanalların son videoları tek akışta (en yeni üstte) + üstte kanal simgeleri. API anahtarı varken kanal başına yaklaşık 1 kota birimi harcar (en çok 20 kanal, kanal başına 3 video).
- Kanal sayfası: kanal adına/simgesine dokununca (ana sayfa kartı, arama > Kanallar, kütüphane, oynatıcı) kanalın bilgisi, abone ol düğmesi ve son videoları.
- Kaldığın yerden devam: bir videoyu kapattığın saniye hatırlanır; tekrar açınca oradan başlar (bitişe 10 sn kala veya bitince sıfırlanır).
- Bildirimde Oynat/Duraklat ve Kapat düğmeleri (ekran kapalıyken kontrol).
- Aboneliği hesaba işleme: Google ile girişliysen abone ol / çık YouTube hesabına da yansır. Hata olursa yalnızca telefonda kalır ve bir mesaj gösterilir.

## Aşama 6'da eklenenler (final)
- YouTube tarzı arayüz: koyu tema, kırmızı logo, üst çubukta arama ve profil, beyaz/gri filtre çipleri, tam genişlik küçük resimler, oynatıcıda başlık + abone ol + çip satırı (Favori, Sonra izle, Hız, Kilitle, Döndür).
- Arka planda oynatma: ekran kapanınca veya uygulamadan çıkınca ses/video durmaz (ön plan servisi + bildirim). Ayarlar > Oynatma'dan kapatılabilir.
- Küçük pencere (PiP): video oynarken ana ekrana çıkınca küçük pencerede devam eder.
- Hesap sekmesi: yerel profil (ad, e-posta) ekleme/düzenleme/kaldırma, istatistikler, API anahtarı, test modu, geçmişi temizleme, hata kaydı görüntüleme/kopyalama.
- Profil yalnızca telefonda saklanır; Google/YouTube hesabıyla senkronize olmaz (bunun için kendi OAuth bilgileriniz gerekir).

## Aşama 5'te eklenenler
- Kütüphane sekmesi: Favoriler, İzleme geçmişi, Sonra izle, Abonelikler (yerel Room veritabanı).
- Oynatıcı ekranında: Favori, Sonra izle ve Abone ol düğmeleri. Video oynamaya başlayınca geçmişe kaydedilir (en fazla 200 kayıt).
- Arama > Kanallar sonuçlarında Abone ol düğmesi.
- Listelerde tek tek kaldırma ve onaylı "Listeyi temizle".
- Veritabanı sürümü 2'ye çıktı. Güncelleme sırasında geliştirme sürümünde eski arama geçmişi bir kez sıfırlanır.

## Aşama 4'te eklenenler
- Arama ekranı: video ve kanal sekmeleri, arama geçmişi (Room), geçmişten tek tek silme / tümünü temizleme, arama önerileri (geçmiş + bilinen başlıklar).
- YouTube Data API v3 (resmi): ana ekran "popüler" listesi, video araması, kanal araması. Ek kütüphane yok (HttpURLConnection + org.json).
- API anahtarı: Ara sekmesinde "API anahtarı gir". Anahtar yalnızca telefonda saklanır. Anahtar yoksa TEST MODU (örnek veri) çalışır.
- Hata durumları: kota dolu, geçersiz anahtar, ağ yok → ekranda açıklama + "Tekrar dene"; ayrıca `crash.log`'a yazılır.
- Room veritabanı (şimdilik yalnızca arama geçmişi). Sonraki aşamada tablolar eklenince geliştirme sürümünde veritabanı sıfırlanabilir.

## API anahtarı nasıl alınır
Google Cloud Console > yeni proje > "YouTube Data API v3"ü etkinleştir > Kimlik bilgileri > API anahtarı oluştur.
Anahtarı uygulama/IP ile kısıtlarsanız istekler reddedilebilir; kısıtsız anahtar kullanın ve paylaşmayın. Günlük ücretsiz kota sınırlıdır (bir arama ≈ 100 birim).

## Aşama 3'te eklenenlerin özeti
Örnek veri, video kartları, resmi YouTube IFrame oynatıcı (10 sn ileri/geri, hız, ekran kilidi, yatay tam ekran), hata kaydı.

## Bilinen sınırlar
- Kod geliştirme ortamında derlenemedi; gerçek derleme GitHub Actions'ta yapılır.
- Kalite seçimi YouTube'un kendi menüsündendir. Reklam engelleme yoktur (YouTube kurallarına aykırı).
- Ana ekranda kart menüsü yok; favori/sonra izle oynatıcı ekranından yapılır. Shorts akışı ve YouTube'un kişisel öneri ana sayfası resmi API'de olmadığı için yoktur.
- Çift dokunup sarma, parlaklık/ses kaydırma gibi kendi oynatıcı hareketleri yok (video YouTube'un kendi kontrolleriyle gelir; üstüne hareket katmanı koymak onun dokunuşlarını engellerdi).

## Telefondan APK üretme (GitHub Actions)
1. Depoda eski ZIP dosyasını silin (Delete file), yenisini yükleyin (Add file > Upload files).
2. Actions sekmesinde derleme başlar; bitince Artifacts > `VancedPlayer-debug-apk` indirin, ZIP'ten çıkan APK'yı kurun.
3. Hata olursa kırmızı adımın log'unu gönderin.
