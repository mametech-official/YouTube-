package com.vancedplayer.app.data.repo

import com.vancedplayer.app.data.local.LibraryDao
import com.vancedplayer.app.data.local.ListType
import com.vancedplayer.app.data.local.SavedVideo
import com.vancedplayer.app.data.local.SubscriptionEntity
import com.vancedplayer.app.data.model.ChannelItem
import com.vancedplayer.app.data.model.Video
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

fun Video.toSaved(type: String, now: Long): SavedVideo = SavedVideo(
    videoId = id,
    listType = type,
    title = title,
    channelId = channelId,
    channelName = channelName,
    category = category,
    views = views,
    publishedAt = publishedAt,
    durationSec = durationSec,
    addedAt = now
)

fun SavedVideo.toVideo(): Video = Video(
    id = videoId,
    title = title,
    channelId = channelId,
    channelName = channelName,
    category = category,
    views = views,
    publishedAt = publishedAt,
    durationSec = durationSec
)

fun ChannelItem.toEntity(now: Long): SubscriptionEntity =
    SubscriptionEntity(id, name, thumbnailUrl, subscribers, description, now)

fun SubscriptionEntity.toItem(): ChannelItem = ChannelItem(channelId, name, subscribers, thumbnailUrl, description)

/** Favoriler, geçmiş, daha sonra izle ve abonelikler (yerel Room veritabanı). */
class LibraryRepository(private val dao: LibraryDao) {

    companion object {
        const val MAX_HISTORY = 200
    }

    fun videos(type: String): Flow<List<Video>> = dao.observe(type).map { list -> list.map { it.toVideo() } }

    fun contains(videoId: String, type: String): Flow<Boolean> = dao.observeContains(videoId, type)

    fun count(type: String): Flow<Int> = dao.observeCount(type)

    suspend fun toggle(video: Video, type: String) {
        if (dao.contains(video.id, type)) {
            dao.remove(video.id, type)
        } else {
            dao.upsert(video.toSaved(type, System.currentTimeMillis()))
        }
    }

    suspend fun remove(videoId: String, type: String) = dao.remove(videoId, type)

    suspend fun clear(type: String) = dao.clear(type)

    suspend fun recordHistory(video: Video) {
        dao.upsert(video.toSaved(ListType.HISTORY, System.currentTimeMillis()))
        dao.trim(ListType.HISTORY, MAX_HISTORY)
    }

    fun subscriptions(): Flow<List<ChannelItem>> = dao.observeSubscriptions().map { l -> l.map { it.toItem() } }

    fun subscribedIds(): Flow<Set<String>> =
        dao.observeSubscriptions().map { l -> l.map { it.channelId }.toSet() }

    fun isSubscribed(channelId: String): Flow<Boolean> = dao.observeSubscribed(channelId)

    fun subscriptionCount(): Flow<Int> = dao.observeSubscriptionCount()

    suspend fun toggleSubscribe(channel: ChannelItem) {
        if (dao.isSubscribed(channel.id)) {
            dao.unsubscribe(channel.id)
        } else {
            dao.subscribe(channel.toEntity(System.currentTimeMillis()))
        }
    }

    suspend fun unsubscribe(channelId: String) = dao.unsubscribe(channelId)

    suspend fun clearSubscriptions() = dao.clearSubscriptions()

    /** YouTube hesabından alınan abonelikleri yerel listeye ekler (var olanları günceller). */
    suspend fun importSubscriptions(channels: List<ChannelItem>) {
        val now = System.currentTimeMillis()
        channels.forEach { dao.subscribe(it.toEntity(now)) }
    }

    suspend fun importVideos(videos: List<Video>, type: String) {
        val now = System.currentTimeMillis()
        videos.forEach { dao.upsert(it.toSaved(type, now)) }
    }
}
