package com.vancedplayer.app.data.remote

import com.vancedplayer.app.data.model.Categories
import com.vancedplayer.app.data.model.ChannelItem
import com.vancedplayer.app.data.model.Video
import com.vancedplayer.app.data.model.VideoComment
import com.vancedplayer.app.data.sample.SampleData
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.Instant
import org.json.JSONObject

class ApiException(message: String, val code: Int = 0) : IOException(message)

/**
 * YouTube Data API v3 (resmi, HTTPS). Anahtar kullanıcıya aittir; günlük kota sınırı geçerlidir.
 * Ek kütüphane gerekmez (HttpURLConnection + org.json).
 */
object YouTubeApi {
    private const val BASE = "https://www.googleapis.com/youtube/v3/"

    // ---- Saf yardımcılar (birim testli) ----

    private val durationRegex = Regex("^P(?:(\\d+)D)?(?:T(?:(\\d+)H)?(?:(\\d+)M)?(?:(\\d+)S)?)?$")

    fun parseDuration(iso: String): Int {
        val m = durationRegex.matchEntire(iso) ?: return 0
        fun g(i: Int) = m.groupValues[i].toIntOrNull() ?: 0
        return g(1) * 86400 + g(2) * 3600 + g(3) * 60 + g(4)
    }

    fun parseTime(iso: String): Long = try {
        Instant.parse(iso).toEpochMilli()
    } catch (_: Exception) {
        0L
    }

    // ---- Genel istekler ----

    suspend fun popular(apiKey: String, categoryId: String?): List<Video> {
        val params = linkedMapOf(
            "part" to "snippet,contentDetails,statistics",
            "chart" to "mostPopular",
            "regionCode" to "TR",
            "maxResults" to "25"
        )
        if (categoryId != null) params["videoCategoryId"] = categoryId
        return parseVideos(get("videos", params, apiKey))
    }

    suspend fun searchVideos(apiKey: String, query: String): List<Video> {
        val found = get(
            "search",
            mapOf("part" to "snippet", "type" to "video", "q" to query, "maxResults" to "20"),
            apiKey
        )
        val ids = found.optJSONArray("items")?.let { arr ->
            (0 until arr.length()).mapNotNull { arr.getJSONObject(it).optJSONObject("id")?.optString("videoId") }
        }.orEmpty().filter { it.isNotBlank() }
        if (ids.isEmpty()) return emptyList()
        val details = get(
            "videos",
            mapOf("part" to "snippet,contentDetails,statistics", "id" to ids.joinToString(",")),
            apiKey
        )
        return parseVideos(details)
    }

    suspend fun searchChannels(apiKey: String, query: String): List<ChannelItem> {
        val found = get(
            "search",
            mapOf("part" to "snippet", "type" to "channel", "q" to query, "maxResults" to "20"),
            apiKey
        )
        val arr = found.optJSONArray("items") ?: return emptyList()
        val base = (0 until arr.length()).mapNotNull { i ->
            val item = arr.getJSONObject(i)
            val id = item.optJSONObject("id")?.optString("channelId").orEmpty()
            val sn = item.optJSONObject("snippet") ?: return@mapNotNull null
            if (id.isBlank()) return@mapNotNull null
            ChannelItem(
                id = id,
                name = sn.optString("title"),
                subscribers = null,
                thumbnailUrl = sn.optJSONObject("thumbnails")?.optJSONObject("default")?.optString("url")
                    ?.takeIf { it.startsWith("http") },
                description = sn.optString("description")
            )
        }
        if (base.isEmpty()) return base
        val stats = try {
            get("channels", mapOf("part" to "statistics", "id" to base.joinToString(",") { it.id }), apiKey)
        } catch (e: IOException) {
            return base
        }
        val subs = HashMap<String, Long>()
        stats.optJSONArray("items")?.let { a ->
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val st = o.optJSONObject("statistics") ?: continue
                if (st.optBoolean("hiddenSubscriberCount", false)) continue
                st.optString("subscriberCount").toLongOrNull()?.let { subs[o.optString("id")] = it }
            }
        }
        return base.map { it.copy(subscribers = subs[it.id]) }
    }

    // ---- Yorumlar (API anahtarı yeterli) ----

    suspend fun comments(apiKey: String, videoId: String): List<VideoComment> {
        val json = get(
            "commentThreads",
            mapOf(
                "part" to "snippet",
                "videoId" to videoId,
                "maxResults" to "20",
                "order" to "relevance",
                "textFormat" to "plainText"
            ),
            apiKey
        )
        val arr = json.optJSONArray("items") ?: return emptyList()
        val out = ArrayList<VideoComment>()
        for (i in 0 until arr.length()) {
            val sn = arr.getJSONObject(i).optJSONObject("snippet")
                ?.optJSONObject("topLevelComment")?.optJSONObject("snippet") ?: continue
            out.add(
                VideoComment(
                    author = sn.optString("authorDisplayName"),
                    text = sn.optString("textDisplay"),
                    likes = sn.optLong("likeCount"),
                    publishedAt = parseTime(sn.optString("publishedAt"))
                )
            )
        }
        return out
    }

    // ---- Google hesabı (OAuth erişim jetonu ile) ----

    suspend fun myChannel(token: String): ChannelItem? {
        val json = get("channels", mapOf("part" to "snippet,statistics", "mine" to "true"), null, token)
        val o = json.optJSONArray("items")?.optJSONObject(0) ?: return null
        val sn = o.optJSONObject("snippet") ?: return null
        return ChannelItem(
            id = o.optString("id"),
            name = sn.optString("title"),
            subscribers = null,
            thumbnailUrl = sn.optJSONObject("thumbnails")?.optJSONObject("default")?.optString("url"),
            description = sn.optString("description")
        )
    }

    suspend fun mySubscriptions(token: String): List<ChannelItem> {
        val json = get(
            "subscriptions",
            mapOf("part" to "snippet", "mine" to "true", "maxResults" to "50", "order" to "alphabetical"),
            null,
            token
        )
        val arr = json.optJSONArray("items") ?: return emptyList()
        val out = ArrayList<ChannelItem>()
        for (i in 0 until arr.length()) {
            val sn = arr.getJSONObject(i).optJSONObject("snippet") ?: continue
            val id = sn.optJSONObject("resourceId")?.optString("channelId").orEmpty()
            if (id.isBlank()) continue
            out.add(
                ChannelItem(
                    id = id,
                    name = sn.optString("title"),
                    subscribers = null,
                    thumbnailUrl = sn.optJSONObject("thumbnails")?.optJSONObject("default")?.optString("url"),
                    description = sn.optString("description")
                )
            )
        }
        return out
    }

    suspend fun likedVideos(token: String): List<Video> = parseVideos(
        get(
            "videos",
            mapOf("part" to "snippet,contentDetails,statistics", "myRating" to "like", "maxResults" to "50"),
            null,
            token
        )
    )

    /** rating: "like" veya "none". */
    suspend fun rate(token: String, videoId: String, rating: String) {
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val url = BASE + "videos/rate?id=" + URLEncoder.encode(videoId, "UTF-8") +
                "&rating=" + URLEncoder.encode(rating, "UTF-8")
            val conn = URL(url).openConnection() as HttpURLConnection
            try {
                conn.connectTimeout = 10_000
                conn.readTimeout = 15_000
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.setFixedLengthStreamingMode(0)
                conn.setRequestProperty("Authorization", "Bearer $token")
                val code = conn.responseCode
                if (code !in 200..299) {
                    val body = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    throw ApiException(errorMessage(code, body), code)
                }
            } finally {
                conn.disconnect()
            }
        }
    }

    // ---- İç ----

    private fun parseVideos(json: JSONObject): List<Video> {
        val arr = json.optJSONArray("items") ?: return emptyList()
        val out = ArrayList<Video>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.optString("id")
            val sn = o.optJSONObject("snippet") ?: continue
            if (id.isBlank()) continue
            val categoryLabel = Categories.all.firstOrNull { it.apiCategoryId == sn.optString("categoryId") }?.label
                ?: "Genel"
            out.add(
                Video(
                    id = id,
                    title = sn.optString("title"),
                    channelId = sn.optString("channelId").ifBlank { SampleData.channelIdOf(sn.optString("channelTitle")) },
                    channelName = sn.optString("channelTitle"),
                    category = categoryLabel,
                    views = o.optJSONObject("statistics")?.optString("viewCount")?.toLongOrNull() ?: 0L,
                    publishedAt = parseTime(sn.optString("publishedAt")),
                    durationSec = parseDuration(o.optJSONObject("contentDetails")?.optString("duration").orEmpty())
                )
            )
        }
        return out
    }

    private suspend fun get(
        path: String,
        params: Map<String, String>,
        apiKey: String?,
        token: String? = null
    ): JSONObject =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val all = if (apiKey != null) params + ("key" to apiKey) else params
            val query = all.entries.joinToString("&") {
                it.key + "=" + URLEncoder.encode(it.value, "UTF-8")
            }
            val conn = URL(BASE + path + "?" + query).openConnection() as HttpURLConnection
            try {
                conn.connectTimeout = 10_000
                conn.readTimeout = 15_000
                conn.requestMethod = "GET"
                conn.setRequestProperty("Accept", "application/json")
                if (token != null) conn.setRequestProperty("Authorization", "Bearer $token")
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) throw ApiException(errorMessage(code, body), code)
                JSONObject(body)
            } finally {
                conn.disconnect()
            }
        }

    private fun errorMessage(code: Int, body: String): String {
        val reason = try {
            JSONObject(body).optJSONObject("error")?.optJSONArray("errors")?.optJSONObject(0)?.optString("reason")
        } catch (_: Exception) {
            null
        }
        val message = try {
            JSONObject(body).optJSONObject("error")?.optString("message")
        } catch (_: Exception) {
            null
        }
        return when {
            reason == "quotaExceeded" || reason == "dailyLimitExceeded" -> "Günlük YouTube API kotası doldu. Yarın tekrar deneyin."
            reason == "commentsDisabled" -> "Bu videoda yorumlar kapalı."
            code == 401 -> "Google oturumu geçersiz. Hesap sekmesinden tekrar giriş yapın."
            reason == "keyInvalid" || (message != null && message.contains("API key", ignoreCase = true)) ->
                "API anahtarı geçersiz veya kısıtlı. Anahtarı kontrol edin."
            code == 403 -> "YouTube API erişimi reddedildi (403)${if (reason != null) ": $reason" else ""}."
            code == 400 && reason != null -> "İstek reddedildi: $reason"
            message != null -> "YouTube API hatası ($code): $message"
            else -> "YouTube API hatası ($code)."
        }
    }
}
