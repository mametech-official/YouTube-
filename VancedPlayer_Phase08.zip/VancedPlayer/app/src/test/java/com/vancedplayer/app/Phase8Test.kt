package com.vancedplayer.app

import com.vancedplayer.app.data.prefs.ResumeLogic
import com.vancedplayer.app.data.remote.YouTubeApi
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class Phase8Test {
    @Test
    fun uploadsPlaylistIdIsDerivedFromChannelId() {
        assertEquals("UUabcdef", YouTubeApi.uploadsPlaylistId("UCabcdef"))
        assertNull(YouTubeApi.uploadsPlaylistId("sample_rickastley"))
        assertNull(YouTubeApi.uploadsPlaylistId("UC"))
        assertNull(YouTubeApi.uploadsPlaylistId(""))
    }

    @Test
    fun resumeStartsFromSavedPositionOnlyWhenUseful() {
        assertEquals(0f, ResumeLogic.startPosition(2f, 0f), 0.001f)
        assertEquals(120f, ResumeLogic.startPosition(120f, 0f), 0.001f)
        assertEquals(120f, ResumeLogic.startPosition(120f, 600f), 0.001f)
        assertEquals(0f, ResumeLogic.startPosition(595f, 600f), 0.001f)
    }

    @Test
    fun finishedVideosClearProgress() {
        assertTrue(ResumeLogic.shouldClear(10f, 600f, true))
        assertTrue(ResumeLogic.shouldClear(595f, 600f, false))
        assertFalse(ResumeLogic.shouldClear(100f, 600f, false))
        assertFalse(ResumeLogic.shouldClear(100f, 0f, false))
    }
}
