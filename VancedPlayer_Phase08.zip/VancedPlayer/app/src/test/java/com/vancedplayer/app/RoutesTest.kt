package com.vancedplayer.app

import com.vancedplayer.app.ui.navigation.Routes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RoutesTest {
    @Test
    fun routesAreUniqueAndNotEmpty() {
        assertEquals(5, Routes.all.size)
        assertEquals(Routes.all.size, Routes.all.toSet().size)
        assertTrue(Routes.all.all { it.isNotBlank() })
    }

    @Test
    fun playerRouteContainsVideoId() {
        assertEquals("player/abc123", Routes.player("abc123"))
        assertTrue(Routes.PLAYER_PATTERN.contains("{videoId}"))
    }

    @Test
    fun channelRouteContainsChannelId() {
        assertEquals("channel/UC123", Routes.channel("UC123"))
        assertTrue(Routes.CHANNEL_PATTERN.contains("{channelId}"))
    }
}
