package com.vancedplayer.app

import com.vancedplayer.app.data.remote.YouTubeApi
import com.vancedplayer.app.util.Suggestions
import org.junit.Assert.assertEquals
import org.junit.Test

class YouTubeApiTest {
    @Test
    fun durationIsParsed() {
        assertEquals(3723, YouTubeApi.parseDuration("PT1H2M3S"))
        assertEquals(45, YouTubeApi.parseDuration("PT45S"))
        assertEquals(600, YouTubeApi.parseDuration("PT10M"))
        assertEquals(0, YouTubeApi.parseDuration("P0D"))
        assertEquals(0, YouTubeApi.parseDuration("saçma"))
    }

    @Test
    fun publishedTimeIsParsed() {
        assertEquals(1_704_164_645_000L, YouTubeApi.parseTime("2024-01-02T03:04:05Z"))
        assertEquals(0L, YouTubeApi.parseTime("bozuk"))
    }

    @Test
    fun suggestionsPreferHistoryAndDeduplicate() {
        val result = Suggestions.build(
            query = "kot",
            history = listOf("kotlin dersi", "android"),
            titles = listOf("Kotlin tutorial", "Jetpack", "kotlin dersi")
        )
        assertEquals(listOf("kotlin dersi", "Kotlin tutorial"), result)
        assertEquals(emptyList<String>(), Suggestions.build("  ", listOf("a"), listOf("b")))
    }
}
