package com.vancedplayer.app.ui.player

import androidx.compose.runtime.compositionLocalOf

/**
 * Oynatıcının durumu. MainActivity küçük pencereye (PiP) geçip geçmeyeceğine, bildirim servisi de
 * başlık ve oynat/duraklat komutlarına buradan ulaşır.
 */
object PlaybackSession {
    @Volatile
    var playerVisible: Boolean = false

    @Volatile
    var playing: Boolean = false

    @Volatile
    var title: String = "Vanced Player"

    /** Bildirimdeki oynat/duraklat düğmesi. Oynatıcı ekranı açıkken ayarlanır. */
    @Volatile
    var onToggle: (() -> Unit)? = null

    /** Bildirimdeki kapat düğmesi. */
    @Volatile
    var onClose: (() -> Unit)? = null

    fun reset() {
        playerVisible = false
        playing = false
        onToggle = null
        onClose = null
    }
}

/** Aktivite küçük pencere (PiP) modunda mı? */
val LocalPipMode = compositionLocalOf { false }
