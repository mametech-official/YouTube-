package com.vancedplayer.app.auth

import android.content.Context
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * Google ile giriş (resmi Google Identity Authorization API).
 * Gerçek kullanım için Google Cloud'da paket adı + SHA-1 ile bir Android OAuth istemcisi gerekir (README).
 */
object GoogleAuth {
    private const val SCOPE_YOUTUBE = "https://www.googleapis.com/auth/youtube"

    private fun request(): AuthorizationRequest =
        AuthorizationRequest.builder().setRequestedScopes(listOf(Scope(SCOPE_YOUTUBE))).build()

    /** Sonuç: izin ekranı gerekiyorsa [AuthorizationResult.hasResolution] true olur. */
    suspend fun authorize(context: Context): AuthorizationResult =
        suspendCancellableCoroutine { cont ->
            Identity.getAuthorizationClient(context.applicationContext)
                .authorize(request())
                .addOnSuccessListener { if (cont.isActive) cont.resume(it) }
                .addOnFailureListener { if (cont.isActive) cont.resumeWithException(it) }
        }

    /** Sessizce erişim jetonu alır; izin ekranı gerekiyorsa null döner. */
    suspend fun token(context: Context): String? {
        val result = authorize(context)
        return if (result.hasResolution()) null else result.accessToken
    }

    fun resultFromIntent(context: Context, data: android.content.Intent?): AuthorizationResult =
        Identity.getAuthorizationClient(context.applicationContext).getAuthorizationResultFromIntent(data)
}
