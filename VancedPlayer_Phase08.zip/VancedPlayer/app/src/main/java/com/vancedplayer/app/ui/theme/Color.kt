package com.vancedplayer.app.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** YouTube karanlık temasına benzer renkler. */
object VpColors {
    val Black = Color(0xFF0F0F0F)
    val Surface = Color(0xFF0F0F0F)
    val Card = Color(0xFF272727)
    val Outline = Color(0xFF3F3F3F)
    val Blue = Color(0xFF3EA6FF)
    val Purple = Color(0xFF3F3F3F)
    val Red = Color(0xFFFF0000)
    val TextPrimary = Color(0xFFF1F1F1)
    val TextSecondary = Color(0xFFAAAAAA)
}

val BrandBrush: Brush = Brush.horizontalGradient(listOf(VpColors.Red, VpColors.Red))
