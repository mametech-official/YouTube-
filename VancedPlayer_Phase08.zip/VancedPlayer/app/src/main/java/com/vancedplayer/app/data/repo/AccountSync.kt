package com.vancedplayer.app.data.repo

import android.content.Context
import com.vancedplayer.app.auth.GoogleAuth
import com.vancedplayer.app.data.prefs.AppPrefs
import com.vancedplayer.app.data.remote.YouTubeApi
import com.vancedplayer.app.util.CrashLogger
import kotlinx.coroutines.CancellationException

/** Google ile girişliyse yerel abonelik değişikliğini YouTube hesabına da işler. */
class AccountSync(private val context: Context, private val prefs: AppPrefs) {

    /** Başarılıysa (veya işlenecek bir şey yoksa) null; aksi halde kullanıcıya gösterilecek kısa mesaj. */
    suspend fun syncSubscription(channelId: String, subscribe: Boolean): String? {
        if (!prefs.googleSignedIn) return null
        if (!channelId.startsWith("UC")) return null
        return try {
            val token = GoogleAuth.token(context)
            if (token == null) {
                "Google oturumu süresi doldu; abonelik yalnızca bu telefonda kaydedildi."
            } else {
                if (subscribe) YouTubeApi.subscribe(token, channelId) else YouTubeApi.unsubscribe(token, channelId)
                null
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            CrashLogger.logHandled("Abonelik hesaba işlenemedi", e)
            "Abonelik hesaba işlenemedi: ${e.message ?: "bilinmeyen hata"}"
        }
    }
}
