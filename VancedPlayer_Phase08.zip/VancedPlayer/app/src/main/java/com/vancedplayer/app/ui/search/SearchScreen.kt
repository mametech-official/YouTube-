package com.vancedplayer.app.ui.search

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.vancedplayer.app.data.model.ChannelItem
import com.vancedplayer.app.ui.components.ApiKeyDialog
import com.vancedplayer.app.ui.components.ChannelAvatar
import com.vancedplayer.app.ui.components.SkeletonVideoCard
import com.vancedplayer.app.ui.components.SubscribeButton
import com.vancedplayer.app.ui.components.VideoCard
import com.vancedplayer.app.ui.components.rememberShimmerBrush
import com.vancedplayer.app.ui.theme.VpColors
import com.vancedplayer.app.util.Formatters

@Composable
fun SearchScreen(onVideoClick: (String) -> Unit, onChannelClick: (String) -> Unit = {}) {
    val vm: SearchViewModel = viewModel()
    val state by vm.state.collectAsState()
    val history by vm.history.collectAsState()
    val subscribedIds by vm.subscribedIds.collectAsState()
    val focusManager = LocalFocusManager.current
    val focusRequester = remember { FocusRequester() }
    var showKeyDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        vm.refreshMode()
        if (state.query.isBlank()) {
            try {
                focusRequester.requestFocus()
            } catch (_: Exception) {
            }
        }
    }

    if (showKeyDialog) {
        ApiKeyDialog(
            currentKey = vm.apiKey(),
            onSave = {
                vm.saveApiKey(it)
                showKeyDialog = false
            },
            onDismiss = { showKeyDialog = false }
        )
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TextField(
            value = state.query,
            onValueChange = { vm.onQueryChange(it) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 12.dp)
                .focusRequester(focusRequester),
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            placeholder = { Text("Video veya kanal ara", color = VpColors.TextSecondary) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = VpColors.TextSecondary) },
            trailingIcon = {
                if (state.query.isNotEmpty()) {
                    IconButton(onClick = { vm.clearQuery() }) {
                        Icon(Icons.Filled.Close, contentDescription = "Temizle", tint = VpColors.TextSecondary)
                    }
                }
            },
            colors = TextFieldDefaults.colors(
                focusedContainerColor = VpColors.Card,
                unfocusedContainerColor = VpColors.Card,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                cursorColor = VpColors.Blue
            ),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                focusManager.clearFocus()
                vm.submit()
            })
        )

        if (state.sampleMode) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Örnek veri modu",
                    color = VpColors.TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { showKeyDialog = true }) { Text("API anahtarı gir", fontSize = 12.sp) }
            }
        } else {
            Spacer(Modifier.height(8.dp))
        }

        when {
            state.submitted != null -> Results(
                state = state,
                onTab = { vm.selectTab(it) },
                onRetry = { vm.retry() },
                onVideoClick = onVideoClick,
                onChannelClick = onChannelClick,
                subscribedIds = subscribedIds,
                onToggleSubscribe = { vm.toggleSubscribe(it) }
            )
            state.query.isBlank() -> HistoryList(
                history = history,
                onPick = { focusManager.clearFocus(); vm.submit(it) },
                onDelete = { vm.deleteHistory(it) },
                onClear = { vm.clearHistory() }
            )
            else -> SuggestionList(
                items = vm.suggestions(state.query, history),
                onPick = { focusManager.clearFocus(); vm.submit(it) }
            )
        }
    }
}

@Composable
private fun HistoryList(
    history: List<String>,
    onPick: (String) -> Unit,
    onDelete: (String) -> Unit,
    onClear: () -> Unit
) {
    if (history.isEmpty()) {
        Centered("Arama geçmişi boş. Bir şey arayın.")
        return
    }
    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Son aramalar",
                    color = VpColors.TextPrimary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onClear) { Text("Tümünü temizle") }
            }
        }
        items(history, key = { it }) { text ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onPick(text) }
                    .padding(start = 16.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.History, contentDescription = null, tint = VpColors.TextSecondary)
                Spacer(Modifier.width(16.dp))
                Text(
                    text,
                    color = VpColors.TextPrimary,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                IconButton(onClick = { onDelete(text) }) {
                    Icon(Icons.Filled.Close, contentDescription = "Geçmişten sil", tint = VpColors.TextSecondary)
                }
            }
        }
    }
}

@Composable
private fun SuggestionList(items: List<String>, onPick: (String) -> Unit) {
    if (items.isEmpty()) {
        Centered("Öneri yok. Aramak için klavyedeki arama tuşuna basın.")
        return
    }
    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
        items(items, key = { it }) { text ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onPick(text) }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Search, contentDescription = null, tint = VpColors.TextSecondary)
                Spacer(Modifier.width(16.dp))
                Text(text, color = VpColors.TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun Results(
    state: SearchViewModel.UiState,
    onTab: (Int) -> Unit,
    onRetry: () -> Unit,
    onVideoClick: (String) -> Unit,
    onChannelClick: (String) -> Unit,
    subscribedIds: Set<String>,
    onToggleSubscribe: (ChannelItem) -> Unit
) {
    val shimmer = rememberShimmerBrush()
    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = state.tab,
            containerColor = VpColors.Black,
            contentColor = VpColors.TextPrimary
        ) {
            Tab(selected = state.tab == 0, onClick = { onTab(0) }, text = { Text("Videolar") })
            Tab(selected = state.tab == 1, onClick = { onTab(1) }, text = { Text("Kanallar") })
        }
        val loading = if (state.tab == 0) state.loading && state.videos.isEmpty() else state.loading && !state.channelsLoaded
        when {
            loading -> LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) { items(3) { SkeletonVideoCard(shimmer) } }
            state.error != null -> Column(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Arama başarısız: ${state.error}",
                    color = VpColors.TextSecondary,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = onRetry) { Text("Tekrar dene") }
            }
            state.tab == 0 -> if (state.videos.isEmpty()) {
                Centered("Video bulunamadı.")
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    items(state.videos, key = { it.id }) { v ->
                        VideoCard(video = v, onClick = { onVideoClick(v.id) })
                    }
                }
            }
            else -> if (state.channels.isEmpty()) {
                Centered("Kanal bulunamadı.")
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(state.channels, key = { it.id }) { c ->
                        ChannelRow(c, onClick = { onChannelClick(c.id) }) {
                            SubscribeButton(
                                subscribed = c.id in subscribedIds,
                                onClick = { onToggleSubscribe(c) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChannelRow(
    channel: ChannelItem,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (channel.thumbnailUrl != null) {
            AsyncImage(
                model = channel.thumbnailUrl,
                contentDescription = channel.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(52.dp).clip(CircleShape)
            )
        } else {
            ChannelAvatar(channel.name, size = 52.dp)
        }
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                channel.name,
                color = VpColors.TextPrimary,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            channel.subscribers?.let {
                Text(Formatters.subscribers(it), color = VpColors.TextSecondary, fontSize = 12.sp)
            }
            if (channel.description.isNotBlank()) {
                Text(
                    channel.description,
                    color = VpColors.TextSecondary,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        trailing?.invoke()
    }
}

@Composable
private fun Centered(text: String) {
    Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = VpColors.TextSecondary, fontSize = 14.sp, textAlign = TextAlign.Center)
    }
}
