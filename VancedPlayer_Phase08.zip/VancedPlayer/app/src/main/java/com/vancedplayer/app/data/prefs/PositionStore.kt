package com.vancedplayer.app.data.prefs

import android.content.Context

/** "Kaldığın yerden devam" için saniye hesaplamaları (saf, birim testli). */
object ResumeLogic {
    const val MIN_SECONDS = 5f
    const val END_MARGIN = 10f

    /** Kayıtlı konum çok başta veya videonun bitişine çok yakınsa baştan başlar. */
    fun startPosition(saved: Float, duration: Float): Float = when {
        saved < MIN_SECONDS -> 0f
        duration > 0f && saved >= duration - END_MARGIN -> 0f
        else -> saved
    }

    /** Kaydedilecek konum var mı (bitişe yakınsa kayıt silinir). */
    fun shouldClear(current: Float, duration: Float, ended: Boolean): Boolean =
        ended || (duration > 0f && current >= duration - END_MARGIN)
}

/** Videoların son izlenen saniyesini telefonda saklar (en çok [MAX] video). */
class PositionStore(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("vp_positions", Context.MODE_PRIVATE)

    fun get(videoId: String): Float = sp.getFloat(POS + videoId, 0f)

    fun save(videoId: String, seconds: Float) {
        if (seconds < ResumeLogic.MIN_SECONDS) return
        sp.edit()
            .putFloat(POS + videoId, seconds)
            .putLong(TIME + videoId, System.currentTimeMillis())
            .apply()
    }

    fun clear(videoId: String) {
        sp.edit().remove(POS + videoId).remove(TIME + videoId).apply()
    }

    /** Çok sayıda kayıt birikirse en eskileri siler. */
    fun trim() {
        val times = HashMap<String, Long>()
        for ((k, v) in sp.all) {
            if (k.startsWith(TIME)) times[k.removePrefix(TIME)] = (v as? Long) ?: 0L
        }
        if (times.size <= MAX) return
        val drop = times.entries.sortedBy { it.value }.take(times.size - MAX + 50)
        val ed = sp.edit()
        drop.forEach { ed.remove(POS + it.key).remove(TIME + it.key) }
        ed.apply()
    }

    private companion object {
        const val POS = "p_"
        const val TIME = "t_"
        const val MAX = 300
    }
}
