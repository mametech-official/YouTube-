package com.vancedplayer.app.data.repo

import com.vancedplayer.app.data.VideoCatalog
import com.vancedplayer.app.data.model.Category
import com.vancedplayer.app.data.model.ChannelItem
import com.vancedplayer.app.data.model.Video
import com.vancedplayer.app.data.prefs.AppPrefs
import com.vancedplayer.app.data.remote.YouTubeApi
import com.vancedplayer.app.data.sample.SampleData
import kotlinx.coroutines.delay

interface VideoRepository {
    /** true ise örnek (test modu) veriler kullanılıyor. */
    fun isSampleData(): Boolean
    suspend fun home(category: Category): List<Video>
    suspend fun searchVideos(query: String): List<Video>
    suspend fun searchChannels(query: String): List<ChannelItem>

    /** Abone olunan kanalların son videoları (en yeni üstte). */
    suspend fun subscriptionFeed(channelIds: List<String>): List<Video>

    suspend fun channelInfo(channelId: String): ChannelItem?

    suspend fun channelVideos(channelId: String): List<Video>
}

object SampleVideoRepository : VideoRepository {
    override fun isSampleData(): Boolean = true

    override suspend fun home(category: Category): List<Video> {
        delay(500)
        val all = SampleData.videos()
        VideoCatalog.put(all)
        return if (category.sampleKey == null) all else all.filter { it.category == category.sampleKey }
    }

    override suspend fun searchVideos(query: String): List<Video> {
        delay(400)
        val all = SampleData.videos()
        VideoCatalog.put(all)
        val q = query.trim()
        return all.filter { it.title.contains(q, ignoreCase = true) || it.channelName.contains(q, ignoreCase = true) }
    }

    override suspend fun searchChannels(query: String): List<ChannelItem> {
        delay(400)
        val q = query.trim()
        return SampleData.channels().filter { it.name.contains(q, ignoreCase = true) }
    }

    override suspend fun subscriptionFeed(channelIds: List<String>): List<Video> {
        delay(400)
        val set = channelIds.toSet()
        val all = SampleData.videos()
        VideoCatalog.put(all)
        return all.filter { it.channelId in set }.sortedByDescending { it.publishedAt }
    }

    override suspend fun channelInfo(channelId: String): ChannelItem? =
        SampleData.channels().firstOrNull { it.id == channelId }

    override suspend fun channelVideos(channelId: String): List<Video> {
        delay(300)
        val all = SampleData.videos()
        VideoCatalog.put(all)
        return all.filter { it.channelId == channelId }.sortedByDescending { it.publishedAt }
    }
}

/** API anahtarı varsa YouTube Data API'yi, yoksa (veya test modunda) örnek verileri kullanır. */
class AppRepository(private val prefs: AppPrefs) : VideoRepository {
    private fun key(): String? =
        if (prefs.forceSample) null else prefs.apiKey.takeIf { it.isNotBlank() }

    override fun isSampleData(): Boolean = key() == null

    override suspend fun home(category: Category): List<Video> {
        val k = key() ?: return SampleVideoRepository.home(category)
        return YouTubeApi.popular(k, category.apiCategoryId).also { VideoCatalog.put(it) }
    }

    override suspend fun searchVideos(query: String): List<Video> {
        val k = key() ?: return SampleVideoRepository.searchVideos(query)
        return YouTubeApi.searchVideos(k, query).also { VideoCatalog.put(it) }
    }

    override suspend fun searchChannels(query: String): List<ChannelItem> {
        val k = key() ?: return SampleVideoRepository.searchChannels(query)
        return YouTubeApi.searchChannels(k, query)
    }

    override suspend fun subscriptionFeed(channelIds: List<String>): List<Video> {
        val k = key() ?: return SampleVideoRepository.subscriptionFeed(channelIds)
        return YouTubeApi.subscriptionFeed(k, channelIds).also { VideoCatalog.put(it) }
    }

    override suspend fun channelInfo(channelId: String): ChannelItem? {
        val k = key() ?: return SampleVideoRepository.channelInfo(channelId)
        return YouTubeApi.channelInfo(k, channelId)
    }

    override suspend fun channelVideos(channelId: String): List<Video> {
        val k = key() ?: return SampleVideoRepository.channelVideos(channelId)
        return YouTubeApi.channelUploads(k, channelId).also { VideoCatalog.put(it) }
    }
}
