package com.vancedplayer.app.ui.library

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vancedplayer.app.data.VideoCatalog
import com.vancedplayer.app.data.local.ListType
import com.vancedplayer.app.data.model.Video
import com.vancedplayer.app.ui.components.ConfirmDialog
import com.vancedplayer.app.ui.components.VideoCard
import com.vancedplayer.app.ui.search.ChannelRow
import com.vancedplayer.app.ui.theme.VpColors

private val tabTitles = listOf("Favoriler", "Geçmiş", "Sonra izle", "Abonelikler")

@Composable
fun LibraryScreen(onVideoClick: (String) -> Unit, onChannelClick: (String) -> Unit = {}) {
    val vm: LibraryViewModel = viewModel()
    val favorites by vm.favorites.collectAsState()
    val history by vm.history.collectAsState()
    val later by vm.later.collectAsState()
    val subscriptions by vm.subscriptions.collectAsState()
    var tab by rememberSaveable { mutableStateOf(0) }
    var confirmClear by remember { mutableStateOf(false) }

    val open: (Video) -> Unit = { video ->
        VideoCatalog.put(listOf(video))
        onVideoClick(video.id)
    }

    if (confirmClear) {
        ConfirmDialog(
            title = "Listeyi temizle",
            message = "Bu listedeki tüm öğeler silinecek. Emin misiniz?",
            confirmLabel = "Temizle",
            onConfirm = {
                when (tab) {
                    0 -> vm.clear(ListType.FAVORITE)
                    1 -> vm.clear(ListType.HISTORY)
                    2 -> vm.clear(ListType.LATER)
                    else -> vm.clearSubscriptions()
                }
                confirmClear = false
            },
            onDismiss = { confirmClear = false }
        )
    }

    val isEmpty = when (tab) {
        0 -> favorites.isEmpty()
        1 -> history.isEmpty()
        2 -> later.isEmpty()
        else -> subscriptions.isEmpty()
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "Kütüphane",
            color = VpColors.TextPrimary,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp)
        )
        ScrollableTabRow(
            selectedTabIndex = tab,
            edgePadding = 8.dp,
            containerColor = VpColors.Black,
            contentColor = VpColors.TextPrimary
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(selected = tab == index, onClick = { tab = index }, text = { Text(title) })
            }
        }
        if (!isEmpty) {
            TextButton(
                onClick = { confirmClear = true },
                modifier = Modifier.align(Alignment.End).padding(end = 8.dp)
            ) { Text("Listeyi temizle") }
        }
        when (tab) {
            0 -> VideoList(
                videos = favorites,
                emptyText = "Henüz favori yok. Bir video oynatırken kalp simgesine dokunun.",
                onOpen = open,
                onRemove = { vm.remove(it, ListType.FAVORITE) }
            )
            1 -> VideoList(
                videos = history,
                emptyText = "İzleme geçmişi boş. Bir video oynattığınızda burada görünür.",
                onOpen = open,
                onRemove = { vm.remove(it, ListType.HISTORY) }
            )
            2 -> VideoList(
                videos = later,
                emptyText = "Liste boş. Bir video oynatırken \"Sonra izle\" düğmesine dokunun.",
                onOpen = open,
                onRemove = { vm.remove(it, ListType.LATER) }
            )
            else -> if (subscriptions.isEmpty()) {
                EmptyText("Abonelik yok. Arama > Kanallar veya bir videonun altından abone olabilirsiniz.")
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(subscriptions, key = { it.id }) { channel ->
                        ChannelRow(channel, onClick = { onChannelClick(channel.id) }) {
                            TextButton(onClick = { vm.unsubscribe(channel.id) }) { Text("Çık") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VideoList(
    videos: List<Video>,
    emptyText: String,
    onOpen: (Video) -> Unit,
    onRemove: (Video) -> Unit
) {
    if (videos.isEmpty()) {
        EmptyText(emptyText)
        return
    }
    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        items(videos, key = { it.id }) { video ->
            VideoCard(
                video = video,
                onClick = { onOpen(video) },
                trailing = {
                    IconButton(onClick = { onRemove(video) }) {
                        Icon(Icons.Filled.Close, contentDescription = "Listeden kaldır", tint = VpColors.TextSecondary)
                    }
                }
            )
        }
    }
}

@Composable
private fun EmptyText(text: String) {
    Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = VpColors.TextSecondary, fontSize = 14.sp, textAlign = TextAlign.Center)
    }
}
