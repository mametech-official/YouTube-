package com.vancedplayer.app.ui.library

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vancedplayer.app.VancedPlayerApp
import com.vancedplayer.app.data.local.ListType
import com.vancedplayer.app.data.model.ChannelItem
import com.vancedplayer.app.data.model.Video
import com.vancedplayer.app.util.CrashLogger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class LibraryViewModel(app: Application) : AndroidViewModel(app) {
    private val container = (app as VancedPlayerApp).container
    private val repo = container.library

    val favorites: StateFlow<List<Video>> = repo.videos(ListType.FAVORITE).asState(emptyList())
    val history: StateFlow<List<Video>> = repo.videos(ListType.HISTORY).asState(emptyList())
    val later: StateFlow<List<Video>> = repo.videos(ListType.LATER).asState(emptyList())
    val subscriptions: StateFlow<List<ChannelItem>> = repo.subscriptions().asState(emptyList())

    private fun <T> kotlinx.coroutines.flow.Flow<T>.asState(initial: T): StateFlow<T> =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), initial)

    fun remove(video: Video, type: String) = launchSafe("Listeden silinemedi") { repo.remove(video.id, type) }

    fun clear(type: String) = launchSafe("Liste temizlenemedi") { repo.clear(type) }

    fun unsubscribe(channelId: String) = launchSafe("Abonelik kaldırılamadı") {
        val message = container.removeSubscription(channelId)
        if (message != null) Toast.makeText(getApplication<Application>(), message, Toast.LENGTH_LONG).show()
    }

    fun clearSubscriptions() = launchSafe("Abonelikler temizlenemedi") { repo.clearSubscriptions() }

    private fun launchSafe(what: String, block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CrashLogger.logHandled(what, e)
            }
        }
    }
}
