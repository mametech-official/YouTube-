package com.vancedplayer.app.ui.player

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.options.IFramePlayerOptions
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView

/**
 * Resmi YouTube IFrame oynatıcısı. Kalite, altyazı ve ayar menüsü YouTube'un kendi kontrolleriyle gelir.
 * [backgroundPlay] açıksa uygulama arka plana geçince veya ekran kapanınca oynatma devam eder.
 */
@Composable
fun YouTubePlayerSurface(
    videoId: String,
    controller: PlayerController,
    modifier: Modifier = Modifier,
    backgroundPlay: Boolean = true,
    startSecond: Float = 0f
) {
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner, backgroundPlay) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP && !backgroundPlay) controller.pause()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    AndroidView(
        modifier = modifier,
        factory = { context ->
            YouTubePlayerView(context).apply {
                enableAutomaticInitialization = false
                if (backgroundPlay) enableBackgroundPlaybackCompat()
                val listener = object : AbstractYouTubePlayerListener() {
                    override fun onReady(youTubePlayer: YouTubePlayer) {
                        controller.attach(youTubePlayer)
                        youTubePlayer.loadVideo(videoId, startSecond)
                    }

                    override fun onStateChange(
                        youTubePlayer: YouTubePlayer,
                        state: PlayerConstants.PlayerState
                    ) {
                        controller.onPlayingChanged(state == PlayerConstants.PlayerState.PLAYING)
                        controller.onEnded(state == PlayerConstants.PlayerState.ENDED)
                    }

                    override fun onVideoDuration(youTubePlayer: YouTubePlayer, duration: Float) {
                        controller.onDuration(duration)
                    }

                    override fun onCurrentSecond(youTubePlayer: YouTubePlayer, second: Float) {
                        controller.onSecond(second)
                    }

                    override fun onError(
                        youTubePlayer: YouTubePlayer,
                        error: PlayerConstants.PlayerError
                    ) {
                        controller.onError(
                            "Video oynatılamadı (${error.name}). Video kaldırılmış veya gömülü oynatmaya kapalı olabilir."
                        )
                    }
                }
                val options = IFramePlayerOptions.Builder()
                    .controls(1)
                    .rel(0)
                    .origin("https://${context.packageName}")
                    .build()
                initialize(listener, options)
            }
        },
        onRelease = { it.release() }
    )
}

/** Kütüphanenin arka plan oynatma ayarını çağırır; yöntem yoksa sessizce geçer (derleme güvenliği). */
private fun YouTubePlayerView.enableBackgroundPlaybackCompat() {
    try {
        javaClass.getMethod("enableBackgroundPlayback", java.lang.Boolean.TYPE).invoke(this, true)
    } catch (_: Throwable) {
    }
}
