package com.vancedplayer.app.ui.channel

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.vancedplayer.app.data.model.ChannelItem
import com.vancedplayer.app.ui.components.ChannelAvatar
import com.vancedplayer.app.ui.components.SkeletonVideoCard
import com.vancedplayer.app.ui.components.SubscribeButton
import com.vancedplayer.app.ui.components.VideoCard
import com.vancedplayer.app.ui.components.rememberShimmerBrush
import com.vancedplayer.app.ui.theme.VpColors
import com.vancedplayer.app.util.Formatters

@Composable
fun ChannelScreen(channelId: String, onBack: () -> Unit, onVideoClick: (String) -> Unit) {
    val vm: ChannelViewModel = viewModel()
    val state by vm.state.collectAsState()
    val subscribed by remember(channelId) { vm.isSubscribed(channelId) }.collectAsState(initial = false)
    val shimmer = rememberShimmerBrush()
    LaunchedEffect(channelId) { vm.load(channelId) }

    val name = state.info?.name ?: state.videos.firstOrNull()?.channelName ?: "Kanal"
    val channel = state.info ?: ChannelItem(channelId, name, null, null, "")

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(end = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Geri", tint = VpColors.TextPrimary)
            }
            Text(
                text = name,
                color = VpColors.TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (channel.thumbnailUrl != null) {
                        AsyncImage(
                            model = channel.thumbnailUrl,
                            contentDescription = channel.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(72.dp).clip(CircleShape)
                        )
                    } else {
                        ChannelAvatar(channel.name, size = 72.dp)
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            channel.name,
                            color = VpColors.TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        channel.subscribers?.let {
                            Text(Formatters.subscribers(it), color = VpColors.TextSecondary, fontSize = 13.sp)
                        }
                    }
                }
                if (channel.description.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        channel.description,
                        color = VpColors.TextSecondary,
                        fontSize = 13.sp,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
                Spacer(Modifier.height(12.dp))
                SubscribeButton(
                    subscribed = subscribed,
                    onClick = { vm.toggleSubscribe(channel) },
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
            when {
                state.loading -> items(2) { Box(Modifier.padding(horizontal = 12.dp)) { SkeletonVideoCard(shimmer) } }
                state.error != null -> item {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            "Videolar yüklenemedi: ${state.error}",
                            color = VpColors.TextSecondary,
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { vm.load(channelId, force = true) }) { Text("Tekrar dene") }
                    }
                }
                state.videos.isEmpty() -> item {
                    Text(
                        if (state.sampleMode) "Bu kanal için örnek video yok. Gerçek içerik için API anahtarı girin." else "Bu kanalda video bulunamadı.",
                        color = VpColors.TextSecondary,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(24.dp)
                    )
                }
                else -> items(state.videos, key = { it.id }) { v ->
                    VideoCard(video = v, edgeToEdge = true, onClick = { onVideoClick(v.id) })
                }
            }
        }
    }
}
