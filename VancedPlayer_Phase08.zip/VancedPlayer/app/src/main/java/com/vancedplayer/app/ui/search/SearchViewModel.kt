package com.vancedplayer.app.ui.search

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vancedplayer.app.VancedPlayerApp
import com.vancedplayer.app.data.VideoCatalog
import com.vancedplayer.app.data.local.SearchHistoryEntity
import com.vancedplayer.app.data.model.ChannelItem
import com.vancedplayer.app.data.model.Video
import com.vancedplayer.app.util.CrashLogger
import com.vancedplayer.app.util.Suggestions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SearchViewModel(app: Application) : AndroidViewModel(app) {

    data class UiState(
        val query: String = "",
        /** Gönderilmiş (sonuçları gösterilen) arama; null ise öneri/geçmiş görünür. */
        val submitted: String? = null,
        val tab: Int = 0,
        val loading: Boolean = false,
        val videos: List<Video> = emptyList(),
        val channels: List<ChannelItem> = emptyList(),
        val channelsLoaded: Boolean = false,
        val error: String? = null,
        val sampleMode: Boolean = true
    )

    private val container = (app as VancedPlayerApp).container
    private val repo = container.repository
    private val dao get() = container.db.searchHistoryDao()

    private val _state = MutableStateFlow(UiState(sampleMode = repo.isSampleData()))
    val state: StateFlow<UiState> = _state.asStateFlow()

    val history: StateFlow<List<String>> = dao.observe(20)
        .map { list -> list.map { it.text } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val subscribedIds: StateFlow<Set<String>> = container.library.subscribedIds()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

    fun toggleSubscribe(channel: ChannelItem) {
        viewModelScope.launch {
            try {
                val message = container.toggleSubscription(channel)
                if (message != null) Toast.makeText(getApplication<Application>(), message, Toast.LENGTH_LONG).show()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CrashLogger.logHandled("Abonelik güncellenemedi", e)
            }
        }
    }

    private var job: Job? = null
    private var channelJob: Job? = null

    fun apiKey(): String = container.prefs.apiKey

    fun refreshMode() {
        _state.update { it.copy(sampleMode = repo.isSampleData()) }
    }

    fun saveApiKey(key: String) {
        container.prefs.apiKey = key
        refreshMode()
        _state.value.submitted?.let { submit(it) }
    }

    fun suggestions(query: String, history: List<String>): List<String> =
        Suggestions.build(query, history, VideoCatalog.titles())

    fun onQueryChange(q: String) {
        _state.update { it.copy(query = q, submitted = null, error = null) }
    }

    fun clearQuery() {
        job?.cancel()
        channelJob?.cancel()
        _state.update { it.copy(query = "", submitted = null, error = null, loading = false) }
    }

    fun submit(text: String = _state.value.query) {
        val q = text.trim()
        if (q.isEmpty()) return
        job?.cancel()
        channelJob?.cancel()
        _state.update {
            it.copy(
                query = q,
                submitted = q,
                tab = 0,
                loading = true,
                error = null,
                videos = emptyList(),
                channels = emptyList(),
                channelsLoaded = false,
                sampleMode = repo.isSampleData()
            )
        }
        viewModelScope.launch {
            try {
                dao.upsert(SearchHistoryEntity(q, System.currentTimeMillis()))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CrashLogger.logHandled("Arama geçmişi kaydedilemedi", e)
            }
        }
        job = viewModelScope.launch {
            try {
                val result = repo.searchVideos(q)
                _state.update { it.copy(loading = false, videos = result) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CrashLogger.logHandled("Video araması başarısız", e)
                _state.update { it.copy(loading = false, error = e.message ?: "Bilinmeyen hata") }
            }
        }
    }

    fun selectTab(index: Int) {
        _state.update { it.copy(tab = index) }
        val s = _state.value
        if (index == 1 && !s.channelsLoaded && s.submitted != null) loadChannels(s.submitted)
    }

    fun retry() {
        val s = _state.value
        val q = s.submitted ?: return
        if (s.tab == 1) loadChannels(q) else submit(q)
    }

    private fun loadChannels(q: String) {
        channelJob?.cancel()
        _state.update { it.copy(loading = true, error = null) }
        channelJob = viewModelScope.launch {
            try {
                val result = repo.searchChannels(q)
                _state.update { it.copy(loading = false, channels = result, channelsLoaded = true) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CrashLogger.logHandled("Kanal araması başarısız", e)
                _state.update { it.copy(loading = false, error = e.message ?: "Bilinmeyen hata") }
            }
        }
    }

    fun deleteHistory(text: String) {
        viewModelScope.launch {
            try {
                dao.delete(text)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CrashLogger.logHandled("Geçmiş silinemedi", e)
            }
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            try {
                dao.clear()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CrashLogger.logHandled("Geçmiş temizlenemedi", e)
            }
        }
    }
}
