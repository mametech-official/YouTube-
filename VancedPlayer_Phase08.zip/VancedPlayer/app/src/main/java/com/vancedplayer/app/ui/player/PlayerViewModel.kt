package com.vancedplayer.app.ui.player

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vancedplayer.app.VancedPlayerApp
import com.vancedplayer.app.data.local.ListType
import com.vancedplayer.app.data.model.ChannelItem
import com.vancedplayer.app.data.model.Video
import com.vancedplayer.app.util.CrashLogger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class PlayerViewModel(app: Application) : AndroidViewModel(app) {
    private val container = (app as VancedPlayerApp).container
    private val lib = container.library

    fun isFavorite(videoId: String): Flow<Boolean> = lib.contains(videoId, ListType.FAVORITE)
    fun isWatchLater(videoId: String): Flow<Boolean> = lib.contains(videoId, ListType.LATER)
    fun isSubscribed(channelId: String): Flow<Boolean> = lib.isSubscribed(channelId)

    fun toggleFavorite(video: Video) = launchSafe("Favori güncellenemedi") { lib.toggle(video, ListType.FAVORITE) }

    fun toggleWatchLater(video: Video) = launchSafe("Liste güncellenemedi") { lib.toggle(video, ListType.LATER) }

    fun toggleSubscribe(video: Video) = launchSafe("Abonelik güncellenemedi") {
        val message = container.toggleSubscription(ChannelItem(video.channelId, video.channelName, null, null, ""))
        if (message != null) Toast.makeText(getApplication<Application>(), message, Toast.LENGTH_LONG).show()
    }

    fun recordHistory(video: Video) = launchSafe("Geçmiş kaydedilemedi") { lib.recordHistory(video) }

    private fun launchSafe(what: String, block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CrashLogger.logHandled(what, e)
            }
        }
    }
}
