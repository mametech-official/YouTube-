package com.vancedplayer.app.ui.subscriptions

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.vancedplayer.app.data.model.ChannelItem
import com.vancedplayer.app.ui.components.ChannelAvatar
import com.vancedplayer.app.ui.components.SkeletonVideoCard
import com.vancedplayer.app.ui.components.VideoCard
import com.vancedplayer.app.ui.components.rememberShimmerBrush
import com.vancedplayer.app.ui.theme.VpColors

@Composable
fun SubscriptionsScreen(onVideoClick: (String) -> Unit, onChannelClick: (String) -> Unit) {
    val vm: SubscriptionsViewModel = viewModel()
    val state by vm.state.collectAsState()
    val channels by vm.channels.collectAsState()
    val shimmer = rememberShimmerBrush()

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Abonelikler",
                color = VpColors.TextPrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            if (channels.isNotEmpty()) {
                TextButton(onClick = { vm.refresh() }) { Text("Yenile") }
            }
        }
        if (channels.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    "Henüz abonelik yok. Arama > Kanallar'dan, bir videonun altından veya Hesap sekmesinde \"YouTube'dan içe aktar\" ile ekleyebilirsiniz.",
                    color = VpColors.TextSecondary,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
            }
            return@Column
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(channels, key = { it.id }) { c -> ChannelBubble(c, onClick = { onChannelClick(c.id) }) }
                }
            }
            if (state.sampleMode) {
                item {
                    Text(
                        "Test modu: örnek videolar gösteriliyor. Gerçek akış için Hesap sekmesinden API anahtarı girin.",
                        color = VpColors.TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
            }
            when {
                state.loading -> items(3) { Box(Modifier.padding(horizontal = 12.dp)) { SkeletonVideoCard(shimmer) } }
                state.error != null -> item {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp, horizontal = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            "Akış yüklenemedi: ${state.error}",
                            color = VpColors.TextSecondary,
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { vm.refresh() }) { Text("Tekrar dene") }
                    }
                }
                state.videos.isEmpty() -> item {
                    Text(
                        "Abone olduğunuz kanallardan gösterilecek video bulunamadı.",
                        color = VpColors.TextSecondary,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(24.dp)
                    )
                }
                else -> items(state.videos, key = { it.id }) { v ->
                    VideoCard(
                        video = v,
                        edgeToEdge = true,
                        onClick = { onVideoClick(v.id) },
                        onChannelClick = { onChannelClick(v.channelId) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ChannelBubble(channel: ChannelItem, onClick: () -> Unit) {
    Column(
        modifier = Modifier.width(68.dp).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (channel.thumbnailUrl != null) {
            AsyncImage(
                model = channel.thumbnailUrl,
                contentDescription = channel.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(56.dp).clip(CircleShape)
            )
        } else {
            ChannelAvatar(channel.name, size = 56.dp)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            channel.name,
            color = VpColors.TextPrimary,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
