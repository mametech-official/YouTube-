package com.vancedplayer.app.ui.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.vancedplayer.app.MainActivity
import com.vancedplayer.app.util.CrashLogger

/**
 * Video oynarken çalışan ön plan servisi. Ekran kapanınca veya uygulamadan çıkılınca Android'in
 * uygulamayı sonlandırmasını önler. Bildirimde Oynat/Duraklat ve Kapat düğmeleri bulunur.
 */
class PlaybackService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // startForegroundService ile başlatıldığı için önce bildirim gösterilmeli.
        val notification = buildNotification(this, PlaybackSession.title, PlaybackSession.playing)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        when (intent?.action) {
            ACTION_TOGGLE -> {
                val toggle = PlaybackSession.onToggle
                if (toggle == null) {
                    stopSelfClean()
                } else {
                    toggle.invoke()
                }
            }
            ACTION_CLOSE -> {
                PlaybackSession.onClose?.invoke()
                stopSelfClean()
            }
        }
        return START_NOT_STICKY
    }

    private fun stopSelfClean() {
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    companion object {
        private const val CHANNEL_ID = "vp_playback"
        private const val NOTIFICATION_ID = 1001
        private const val ACTION_TOGGLE = "com.vancedplayer.app.action.TOGGLE"
        private const val ACTION_CLOSE = "com.vancedplayer.app.action.CLOSE"

        @Volatile
        var running: Boolean = false

        private fun ensureChannel(context: Context) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "Oynatma", NotificationManager.IMPORTANCE_LOW)
                )
            }
        }

        private fun servicePending(context: Context, action: String, requestCode: Int): PendingIntent =
            PendingIntent.getForegroundService(
                context,
                requestCode,
                Intent(context, PlaybackService::class.java).setAction(action),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        fun buildNotification(context: Context, title: String, playing: Boolean): Notification {
            ensureChannel(context)
            val open = PendingIntent.getActivity(
                context,
                0,
                Intent(context, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val toggleAction = Notification.Action.Builder(
                Icon.createWithResource(
                    context,
                    if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                ),
                if (playing) "Duraklat" else "Oynat",
                servicePending(context, ACTION_TOGGLE, 1)
            ).build()
            val closeAction = Notification.Action.Builder(
                Icon.createWithResource(context, android.R.drawable.ic_menu_close_clear_cancel),
                "Kapat",
                servicePending(context, ACTION_CLOSE, 2)
            ).build()
            return Notification.Builder(context, CHANNEL_ID)
                .setContentTitle(title.ifBlank { "Vanced Player" })
                .setContentText(if (playing) "Oynatılıyor" else "Duraklatıldı")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(open)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .addAction(toggleAction)
                .addAction(closeAction)
                .setStyle(Notification.MediaStyle().setShowActionsInCompactView(0, 1))
                .build()
        }

        fun start(context: Context) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, PlaybackService::class.java))
            } catch (e: Exception) {
                CrashLogger.logHandled("Oynatma servisi başlatılamadı", e)
            }
        }

        /** Çalışan servisin bildirimini (oynat/duraklat simgesi, başlık) günceller; servis başlatmaz. */
        fun update(context: Context) {
            if (!running) return
            try {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(NOTIFICATION_ID, buildNotification(context, PlaybackSession.title, PlaybackSession.playing))
            } catch (e: Exception) {
                CrashLogger.logHandled("Bildirim güncellenemedi", e)
            }
        }

        fun stop(context: Context) {
            try {
                context.stopService(Intent(context, PlaybackService::class.java))
            } catch (e: Exception) {
                CrashLogger.logHandled("Oynatma servisi durdurulamadı", e)
            }
        }
    }
}
