package com.vancedplayer.app.ui.subscriptions

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vancedplayer.app.VancedPlayerApp
import com.vancedplayer.app.data.model.ChannelItem
import com.vancedplayer.app.data.model.Video
import com.vancedplayer.app.util.CrashLogger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SubscriptionsViewModel(app: Application) : AndroidViewModel(app) {

    data class UiState(
        val loading: Boolean = false,
        val videos: List<Video> = emptyList(),
        val error: String? = null,
        val sampleMode: Boolean = true
    )

    private val container = (app as VancedPlayerApp).container
    private val repo = container.repository

    val channels: StateFlow<List<ChannelItem>> = container.library.subscriptions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _state = MutableStateFlow(UiState(sampleMode = repo.isSampleData()))
    val state: StateFlow<UiState> = _state.asStateFlow()
    private var job: Job? = null

    init {
        viewModelScope.launch {
            container.library.subscriptions()
                .map { list -> list.map { it.id } }
                .distinctUntilChanged()
                .collect { ids -> load(ids) }
        }
    }

    fun refresh() = load(channels.value.map { it.id })

    private fun load(ids: List<String>) {
        job?.cancel()
        if (ids.isEmpty()) {
            _state.value = UiState(sampleMode = repo.isSampleData())
            return
        }
        job = viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null, sampleMode = repo.isSampleData()) }
            try {
                val list = repo.subscriptionFeed(ids)
                _state.update { it.copy(loading = false, videos = list) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CrashLogger.logHandled("Abonelik akışı yüklenemedi", e)
                _state.update { it.copy(loading = false, error = e.message ?: "Bilinmeyen hata") }
            }
        }
    }
}
