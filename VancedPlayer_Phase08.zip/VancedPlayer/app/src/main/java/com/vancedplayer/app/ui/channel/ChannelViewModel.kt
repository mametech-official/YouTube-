package com.vancedplayer.app.ui.channel

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vancedplayer.app.VancedPlayerApp
import com.vancedplayer.app.data.model.ChannelItem
import com.vancedplayer.app.data.model.Video
import com.vancedplayer.app.util.CrashLogger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class ChannelViewModel(app: Application) : AndroidViewModel(app) {

    data class UiState(
        val loading: Boolean = true,
        val info: ChannelItem? = null,
        val videos: List<Video> = emptyList(),
        val error: String? = null,
        val sampleMode: Boolean = true
    )

    private val container = (app as VancedPlayerApp).container
    private val repo = container.repository
    private val _state = MutableStateFlow(UiState(sampleMode = repo.isSampleData()))
    val state: StateFlow<UiState> = _state.asStateFlow()
    private var job: Job? = null
    private var loadedId: String? = null

    fun isSubscribed(channelId: String): Flow<Boolean> = container.library.isSubscribed(channelId)

    fun load(channelId: String, force: Boolean = false) {
        if (!force && loadedId == channelId) return
        loadedId = channelId
        job?.cancel()
        job = viewModelScope.launch {
            _state.value = UiState(loading = true, sampleMode = repo.isSampleData())
            try {
                // Bilgi alınamazsa videolar yine de gösterilir.
                val info = try {
                    repo.channelInfo(channelId)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    CrashLogger.logHandled("Kanal bilgisi alınamadı", e)
                    null
                }
                _state.update { it.copy(info = info) }
                val videos = repo.channelVideos(channelId)
                _state.update { it.copy(loading = false, videos = videos) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CrashLogger.logHandled("Kanal videoları yüklenemedi", e)
                _state.update { it.copy(loading = false, error = e.message ?: "Bilinmeyen hata") }
            }
        }
    }

    fun toggleSubscribe(channel: ChannelItem) {
        viewModelScope.launch {
            try {
                val message = container.toggleSubscription(channel)
                if (message != null) Toast.makeText(getApplication<Application>(), message, Toast.LENGTH_LONG).show()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CrashLogger.logHandled("Abonelik güncellenemedi", e)
            }
        }
    }
}
