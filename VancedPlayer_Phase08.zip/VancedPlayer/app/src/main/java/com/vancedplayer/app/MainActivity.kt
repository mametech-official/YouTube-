package com.vancedplayer.app

import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import com.vancedplayer.app.ui.navigation.MainScreen
import com.vancedplayer.app.ui.player.LocalPipMode
import com.vancedplayer.app.ui.player.PlaybackSession
import com.vancedplayer.app.ui.theme.VancedPlayerTheme
import com.vancedplayer.app.util.CrashLogger

class MainActivity : ComponentActivity() {
    private val pipMode = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VancedPlayerTheme {
                CompositionLocalProvider(LocalPipMode provides pipMode.value) {
                    MainScreen()
                }
            }
        }
    }

    /** Video oynarken ana ekrana çıkılırsa küçük pencerede (PiP) oynatmaya devam et. */
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        val prefs = (application as VancedPlayerApp).container.prefs
        if (Build.VERSION.SDK_INT >= 26 && prefs.pipEnabled &&
            PlaybackSession.playerVisible && PlaybackSession.playing
        ) {
            try {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } catch (e: Exception) {
                CrashLogger.logHandled("Küçük pencere açılamadı", e)
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        pipMode.value = isInPictureInPictureMode
    }
}
