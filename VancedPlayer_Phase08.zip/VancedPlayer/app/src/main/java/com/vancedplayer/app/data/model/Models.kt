package com.vancedplayer.app.data.model

data class Video(
    val id: String,
    val title: String,
    val channelId: String,
    val channelName: String,
    val category: String,
    val views: Long,
    val publishedAt: Long,
    val durationSec: Int
) {
    val thumbnailUrl: String get() = "https://i.ytimg.com/vi/$id/hqdefault.jpg"
}

data class Category(
    val label: String,
    /** Örnek veri modunda filtre anahtarı (null = hepsi). */
    val sampleKey: String?,
    /** YouTube Data API videoCategoryId değeri (null = hepsi). */
    val apiCategoryId: String?
)

object Categories {
    val all: List<Category> = listOf(
        Category("Tümü", null, null),
        Category("Müzik", "Müzik", "10"),
        Category("Oyun", "Oyun", "20"),
        Category("Haber", "Haber", "25"),
        Category("Spor", "Spor", "17"),
        Category("Teknoloji", "Teknoloji", "28"),
        Category("Film", "Film", "1"),
        Category("Eğitim", "Eğitim", "27")
    )
}

data class VideoComment(
    val author: String,
    val text: String,
    val likes: Long,
    val publishedAt: Long
)

data class ChannelItem(
    val id: String,
    val name: String,
    val subscribers: Long?,
    val thumbnailUrl: String?,
    val description: String
)
