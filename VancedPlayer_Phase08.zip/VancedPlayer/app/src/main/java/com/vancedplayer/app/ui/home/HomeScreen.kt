package com.vancedplayer.app.ui.home

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vancedplayer.app.VancedPlayerApp
import com.vancedplayer.app.data.model.Categories
import com.vancedplayer.app.ui.components.ChannelAvatar
import com.vancedplayer.app.ui.components.SkeletonVideoCard
import com.vancedplayer.app.ui.components.VideoCard
import com.vancedplayer.app.ui.components.rememberShimmerBrush
import com.vancedplayer.app.ui.theme.VpColors

@Composable
fun HomeScreen(
    onSearchClick: () -> Unit,
    onProfileClick: () -> Unit,
    onVideoClick: (String) -> Unit,
    onChannelClick: (String) -> Unit = {}
) {
    val vm: HomeViewModel = viewModel()
    val state by vm.state.collectAsState()
    val shimmer = rememberShimmerBrush()
    LaunchedEffect(Unit) { vm.refreshIfModeChanged() }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(top = 4.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item { TopBar(onSearch = onSearchClick, onProfile = onProfileClick) }
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(Categories.all) { index, category ->
                    CategoryChip(
                        text = category.label,
                        selected = index == state.categoryIndex,
                        onClick = { vm.selectCategory(index) }
                    )
                }
            }
        }
        if (state.sampleMode) {
            item {
                Text(
                    text = "Test modu: örnek veriler gösteriliyor. Gerçek içerik için Ara sekmesinden API anahtarı girin.",
                    color = VpColors.TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
            }
        }
        when {
            state.loading -> items(3) { Box(Modifier.padding(horizontal = 12.dp)) { SkeletonVideoCard(shimmer) } }
            state.error != null -> item {
                MessageBlock(
                    text = "Videolar yüklenemedi: ${state.error}",
                    actionLabel = "Tekrar dene",
                    onAction = { vm.load() }
                )
            }
            state.videos.isEmpty() -> item {
                MessageBlock(
                    text = if (state.sampleMode) "Bu kategoride örnek video yok. Gerçek içerik için Ara sekmesinden API anahtarı girin." else "Bu kategoride video bulunamadı.",
                    actionLabel = null,
                    onAction = {}
                )
            }
            else -> items(state.videos, key = { it.id }) { video ->
                VideoCard(
                    video = video,
                    edgeToEdge = true,
                    onClick = { onVideoClick(video.id) },
                    onChannelClick = { onChannelClick(video.channelId) }
                )
            }
        }
    }
}

@Composable
private fun MessageBlock(text: String, actionLabel: String?, onAction: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text, color = VpColors.TextSecondary, fontSize = 14.sp, textAlign = TextAlign.Center)
        if (actionLabel != null) {
            Spacer(Modifier.height(12.dp))
            Button(onClick = onAction) { Text(actionLabel) }
        }
    }
}

@Composable
private fun TopBar(onSearch: () -> Unit, onProfile: () -> Unit) {
    val context = LocalContext.current
    val name = (context.applicationContext as VancedPlayerApp).container.prefs.profileName
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(width = 32.dp, height = 22.dp).clip(RoundedCornerShape(6.dp)).background(VpColors.Red),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(8.dp))
        Text(
            text = "Vanced Player",
            color = VpColors.TextPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f)
        )
        IconButton(onClick = onSearch) {
            Icon(Icons.Filled.Search, contentDescription = "Ara", tint = VpColors.TextPrimary)
        }
        IconButton(onClick = onProfile) {
            if (name.isBlank()) {
                Icon(Icons.Filled.AccountCircle, contentDescription = "Hesap", tint = VpColors.TextPrimary)
            } else {
                ChannelAvatar(name, size = 28.dp)
            }
        }
    }
}

@Composable
private fun CategoryChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val textColor by animateColorAsState(
        targetValue = if (selected) Color.Black else VpColors.TextPrimary,
        label = "chipText"
    )
    val background = Modifier.background(if (selected) Color.White else VpColors.Card)
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .then(background)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(text, color = textColor, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}
