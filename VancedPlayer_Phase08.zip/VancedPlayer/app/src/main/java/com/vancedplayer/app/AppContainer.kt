package com.vancedplayer.app

import android.content.Context
import com.vancedplayer.app.data.local.AppDatabase
import com.vancedplayer.app.data.model.ChannelItem
import com.vancedplayer.app.data.prefs.AppPrefs
import com.vancedplayer.app.data.prefs.PositionStore
import com.vancedplayer.app.data.repo.AccountSync
import com.vancedplayer.app.data.repo.AppRepository
import com.vancedplayer.app.data.repo.LibraryRepository
import com.vancedplayer.app.data.repo.VideoRepository

/** Uygulama genelinde paylaşılan bağımlılıklar (basit el ile bağımlılık enjeksiyonu). */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    val prefs = AppPrefs(appContext)
    val db: AppDatabase by lazy { AppDatabase.build(appContext) }
    val repository: VideoRepository = AppRepository(prefs)
    val library: LibraryRepository by lazy { LibraryRepository(db.libraryDao()) }
    val positions = PositionStore(appContext)
    val accountSync = AccountSync(appContext, prefs)

    /** Yerel aboneliği tersine çevirir, girişliyse hesaba da işler. Hata mesajı (varsa) döner. */
    suspend fun toggleSubscription(channel: ChannelItem): String? {
        val nowSubscribed = library.toggleSubscribe(channel)
        return accountSync.syncSubscription(channel.id, nowSubscribed)
    }

    suspend fun removeSubscription(channelId: String): String? {
        library.unsubscribe(channelId)
        return accountSync.syncSubscription(channelId, false)
    }
}
