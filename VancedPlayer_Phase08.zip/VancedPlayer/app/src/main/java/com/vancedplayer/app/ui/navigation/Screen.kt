package com.vancedplayer.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Subscriptions
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.ui.graphics.vector.ImageVector

object Routes {
    const val HOME = "home"
    const val SEARCH = "search"
    const val SUBSCRIPTIONS = "subscriptions"
    const val LIBRARY = "library"
    const val SETTINGS = "settings"
    const val PLAYER_PATTERN = "player/{videoId}"
    fun player(videoId: String) = "player/$videoId"
    const val CHANNEL_PATTERN = "channel/{channelId}"
    fun channel(channelId: String) = "channel/$channelId"
    val all = listOf(HOME, SEARCH, SUBSCRIPTIONS, LIBRARY, SETTINGS)
}

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    data object Home : Screen(Routes.HOME, "Ana Sayfa", Icons.Filled.Home)
    data object Search : Screen(Routes.SEARCH, "Ara", Icons.Filled.Search)
    data object Subscriptions : Screen(Routes.SUBSCRIPTIONS, "Abonelikler", Icons.Filled.Subscriptions)
    data object Library : Screen(Routes.LIBRARY, "Kütüphane", Icons.Filled.VideoLibrary)
    data object Settings : Screen(Routes.SETTINGS, "Hesap", Icons.Filled.AccountCircle)

    companion object {
        val bottomItems: List<Screen> by lazy { listOf(Home, Search, Subscriptions, Library, Settings) }
    }
}
