package com.vancedplayer.app

import com.vancedplayer.app.data.model.Categories
import com.vancedplayer.app.data.sample.SampleData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SampleDataTest {
    @Test
    fun sampleVideosAreValid() {
        val videos = SampleData.videos(now = 1_700_000_000_000L)
        assertTrue(videos.size >= 5)
        assertEquals(videos.size, videos.map { it.id }.toSet().size)
        assertTrue(videos.all { it.id.length == 11 && it.title.isNotBlank() && it.channelName.isNotBlank() })
        assertTrue(videos.all { it.publishedAt < 1_700_000_000_000L })
        assertTrue(videos.all { it.thumbnailUrl.contains(it.id) })
    }

    @Test
    fun categoriesAreConsistent() {
        assertEquals(null, Categories.all.first().sampleKey)
        val ids = Categories.all.mapNotNull { it.apiCategoryId }
        assertEquals(ids.size, ids.toSet().size)
    }
}
