package com.vancedplayer.app

import org.junit.Assert.assertEquals
import org.junit.Test

class SanityTest {
    @Test
    fun appPackageIsCorrect() {
        assertEquals("com.vancedplayer.app", VancedPlayerApp::class.java.`package`?.name)
    }
}
