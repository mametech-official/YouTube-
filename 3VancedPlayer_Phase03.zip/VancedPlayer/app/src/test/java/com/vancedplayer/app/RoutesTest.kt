package com.vancedplayer.app

import com.vancedplayer.app.ui.navigation.Routes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RoutesTest {
    @Test
    fun routesAreUniqueAndNotEmpty() {
        assertEquals(4, Routes.all.size)
        assertEquals(Routes.all.size, Routes.all.toSet().size)
        assertTrue(Routes.all.all { it.isNotBlank() })
    }

    @Test
    fun playerRouteContainsVideoId() {
        assertEquals("player/abc123", Routes.player("abc123"))
        assertTrue(Routes.PLAYER_PATTERN.contains("{videoId}"))
    }
}
