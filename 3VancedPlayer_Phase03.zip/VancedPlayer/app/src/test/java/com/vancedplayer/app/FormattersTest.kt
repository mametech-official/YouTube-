package com.vancedplayer.app

import com.vancedplayer.app.util.Formatters
import org.junit.Assert.assertEquals
import org.junit.Test

class FormattersTest {
    @Test
    fun viewsAreShortened() {
        assertEquals("999 görüntüleme", Formatters.views(999))
        assertEquals("15 B görüntüleme", Formatters.views(15_000))
        assertEquals("1,2 Mn görüntüleme", Formatters.views(1_234_567))
        assertEquals("2 Mr görüntüleme", Formatters.views(2_000_000_000))
    }

    @Test
    fun durationIsFormatted() {
        assertEquals("0:00", Formatters.duration(0))
        assertEquals("1:05", Formatters.duration(65))
        assertEquals("1:02:05", Formatters.duration(3725))
    }

    @Test
    fun relativeTimeIsFormatted() {
        val now = 10_000_000_000_000L
        val day = 86_400_000L
        assertEquals("az önce", Formatters.relative(now - 30_000L, now))
        assertEquals("5 dakika önce", Formatters.relative(now - 5 * 60_000L, now))
        assertEquals("2 saat önce", Formatters.relative(now - 2 * 3_600_000L, now))
        assertEquals("3 gün önce", Formatters.relative(now - 3 * day, now))
        assertEquals("2 ay önce", Formatters.relative(now - 60 * day, now))
        assertEquals("2 yıl önce", Formatters.relative(now - 800 * day, now))
    }
}
