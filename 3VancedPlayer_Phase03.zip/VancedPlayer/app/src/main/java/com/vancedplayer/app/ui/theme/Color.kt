package com.vancedplayer.app.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object VpColors {
    val Black = Color(0xFF000000)
    val Surface = Color(0xFF0D0D0F)
    val Card = Color(0xFF1A1A1F)
    val Outline = Color(0xFF2C2C34)
    val Blue = Color(0xFF3B82F6)
    val Purple = Color(0xFF8B5CF6)
    val Red = Color(0xFFFF3B4E)
    val TextPrimary = Color(0xFFF4F4F6)
    val TextSecondary = Color(0xFF9A9AA5)
}

val BrandBrush: Brush = Brush.horizontalGradient(
    listOf(VpColors.Blue, VpColors.Purple, VpColors.Red)
)
