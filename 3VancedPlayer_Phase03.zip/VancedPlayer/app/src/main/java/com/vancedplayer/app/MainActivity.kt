package com.vancedplayer.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.vancedplayer.app.ui.navigation.MainScreen
import com.vancedplayer.app.ui.theme.VancedPlayerTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VancedPlayerTheme {
                MainScreen()
            }
        }
    }
}
