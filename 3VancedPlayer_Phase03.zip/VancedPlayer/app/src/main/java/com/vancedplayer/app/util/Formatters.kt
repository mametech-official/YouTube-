package com.vancedplayer.app.util

object Formatters {
    private fun short(v: Double): String {
        val r = Math.round(v * 10) / 10.0
        return if (r % 1.0 == 0.0) r.toLong().toString() else r.toString().replace('.', ',')
    }

    fun views(v: Long): String {
        val text = when {
            v >= 1_000_000_000L -> short(v / 1e9) + " Mr"
            v >= 1_000_000L -> short(v / 1e6) + " Mn"
            v >= 1_000L -> short(v / 1e3) + " B"
            else -> v.toString()
        }
        return "$text görüntüleme"
    }

    fun subscribers(v: Long): String {
        val text = when {
            v >= 1_000_000_000L -> short(v / 1e9) + " Mr"
            v >= 1_000_000L -> short(v / 1e6) + " Mn"
            v >= 1_000L -> short(v / 1e3) + " B"
            else -> v.toString()
        }
        return "$text abone"
    }

    fun duration(totalSec: Int): String {
        val s = if (totalSec < 0) 0 else totalSec
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }

    fun relative(publishedAt: Long, now: Long): String {
        val diff = now - publishedAt
        val minutes = diff / 60_000L
        val hours = diff / 3_600_000L
        val days = diff / 86_400_000L
        return when {
            diff < 60_000L -> "az önce"
            minutes < 60 -> "$minutes dakika önce"
            hours < 24 -> "$hours saat önce"
            days < 30 -> "$days gün önce"
            days < 365 -> "${days / 30} ay önce"
            else -> "${days / 365} yıl önce"
        }
    }
}
