package com.vancedplayer.app.data

import com.vancedplayer.app.data.model.Video
import java.util.concurrent.ConcurrentHashMap

/** Yüklenen videoları bellekte tutar; oynatıcı ekranı başlık/kanal bilgisini buradan alır. */
object VideoCatalog {
    private const val MAX = 300
    private val cache = ConcurrentHashMap<String, Video>()

    fun put(videos: List<Video>) {
        if (cache.size > MAX) cache.clear()
        videos.forEach { cache[it.id] = it }
    }

    fun get(id: String): Video? = cache[id]

    fun related(id: String, limit: Int): List<Video> =
        cache.values.filter { it.id != id }.sortedBy { it.id }.take(limit)
}
