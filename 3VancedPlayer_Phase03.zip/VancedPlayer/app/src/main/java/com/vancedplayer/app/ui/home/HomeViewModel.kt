package com.vancedplayer.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vancedplayer.app.data.model.Categories
import com.vancedplayer.app.data.model.Video
import com.vancedplayer.app.data.repo.SampleVideoRepository
import com.vancedplayer.app.data.repo.VideoRepository
import com.vancedplayer.app.util.CrashLogger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class HomeViewModel : ViewModel() {

    data class UiState(
        val loading: Boolean = true,
        val videos: List<Video> = emptyList(),
        val error: String? = null,
        val categoryIndex: Int = 0,
        val sampleMode: Boolean = true
    )

    private val repo: VideoRepository = SampleVideoRepository
    private val _state = MutableStateFlow(UiState(sampleMode = repo.isSampleData))
    val state: StateFlow<UiState> = _state.asStateFlow()
    private var job: Job? = null

    init {
        load()
    }

    fun selectCategory(index: Int) {
        if (index == _state.value.categoryIndex) return
        _state.update { it.copy(categoryIndex = index) }
        load()
    }

    fun load() {
        job?.cancel()
        val category = Categories.all[_state.value.categoryIndex]
        job = viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            try {
                val list = repo.home(category)
                _state.update { it.copy(loading = false, videos = list) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CrashLogger.logHandled("Ana ekran yüklenemedi", e)
                _state.update { it.copy(loading = false, error = e.message ?: "Bilinmeyen hata") }
            }
        }
    }
}
