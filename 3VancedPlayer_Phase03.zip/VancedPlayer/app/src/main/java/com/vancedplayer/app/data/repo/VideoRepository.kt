package com.vancedplayer.app.data.repo

import com.vancedplayer.app.data.VideoCatalog
import com.vancedplayer.app.data.model.Category
import com.vancedplayer.app.data.model.Video
import com.vancedplayer.app.data.sample.SampleData
import kotlinx.coroutines.delay

interface VideoRepository {
    val isSampleData: Boolean
    suspend fun home(category: Category): List<Video>
}

object SampleVideoRepository : VideoRepository {
    override val isSampleData: Boolean = true

    override suspend fun home(category: Category): List<Video> {
        delay(500)
        val all = SampleData.videos()
        VideoCatalog.put(all)
        return if (category.sampleKey == null) all else all.filter { it.category == category.sampleKey }
    }
}
