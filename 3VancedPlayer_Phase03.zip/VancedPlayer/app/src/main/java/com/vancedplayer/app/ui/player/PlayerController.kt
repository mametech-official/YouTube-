package com.vancedplayer.app.ui.player

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer

/** Resmi YouTube IFrame oynatıcısını Compose durumuna bağlar. */
class PlayerController(initialSpeed: PlayerConstants.PlaybackRate = PlayerConstants.PlaybackRate.RATE_1) {
    private var player: YouTubePlayer? = null
    private var speedApplied = false

    var ready by mutableStateOf(false)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var currentSecond by mutableFloatStateOf(0f)
        private set
    var speed by mutableStateOf(initialSpeed)
        private set
    var errorMessage by mutableStateOf<String?>(null)
        private set

    fun attach(p: YouTubePlayer) {
        player = p
        ready = true
    }

    fun onPlayingChanged(playing: Boolean) {
        isPlaying = playing
        if (playing && !speedApplied) {
            speedApplied = true
            if (speed != PlayerConstants.PlaybackRate.RATE_1) player?.setPlaybackRate(speed)
        }
    }

    fun onSecond(second: Float) {
        currentSecond = second
    }

    fun onError(message: String) {
        errorMessage = message
    }

    fun togglePlay() {
        val p = player ?: return
        if (isPlaying) p.pause() else p.play()
    }

    fun pause() {
        player?.pause()
    }

    fun seekBy(deltaSeconds: Float) {
        player?.seekTo((currentSecond + deltaSeconds).coerceAtLeast(0f))
    }

    fun setSpeed(rate: PlayerConstants.PlaybackRate) {
        speed = rate
        player?.setPlaybackRate(rate)
    }
}
