package com.vancedplayer.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = VpColors.Blue,
    secondary = VpColors.Purple,
    tertiary = VpColors.Red,
    background = VpColors.Black,
    surface = VpColors.Surface,
    surfaceVariant = VpColors.Card,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = VpColors.TextPrimary,
    onSurface = VpColors.TextPrimary,
    onSurfaceVariant = VpColors.TextSecondary,
    outline = VpColors.Outline
)

@Composable
fun VancedPlayerTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
