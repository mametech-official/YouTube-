package com.vancedplayer.app.util

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Çökmeleri ve yakalanan hataları dosyaya yazar (Ayarlar'da gösterilecek). */
object CrashLogger {
    private const val TAG = "VancedPlayer"
    private const val FILE_NAME = "crash.log"
    private const val MAX_BYTES = 64 * 1024

    @Volatile
    private var dir: File? = null

    fun install(context: Context) {
        dir = context.applicationContext.filesDir
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Log.e(TAG, "Uncaught exception on ${thread.name}", throwable)
            write("ÇÖKME [${thread.name}]", throwable)
            previous?.uncaughtException(thread, throwable)
        }
    }

    fun logHandled(message: String, error: Throwable) {
        Log.w(TAG, message, error)
        write(message, error)
    }

    fun read(): String = try {
        val d = dir
        if (d == null) "" else File(d, FILE_NAME).takeIf { it.exists() }?.readText() ?: ""
    } catch (_: Throwable) {
        ""
    }

    fun clear() {
        try {
            dir?.let { File(it, FILE_NAME).delete() }
        } catch (_: Throwable) {
        }
    }

    private fun write(title: String, error: Throwable) {
        try {
            val d = dir ?: return
            val f = File(d, FILE_NAME)
            if (f.exists() && f.length() > MAX_BYTES) f.delete()
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            f.appendText("[$time] $title\n${Log.getStackTraceString(error)}\n\n")
        } catch (_: Throwable) {
        }
    }
}
