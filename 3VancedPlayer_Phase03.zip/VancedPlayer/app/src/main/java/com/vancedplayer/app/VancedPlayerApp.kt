package com.vancedplayer.app

import android.app.Application
import com.vancedplayer.app.util.CrashLogger

class VancedPlayerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLogger.install(this)
    }
}
