package com.vancedplayer.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.ui.graphics.vector.ImageVector

object Routes {
    const val HOME = "home"
    const val SEARCH = "search"
    const val LIBRARY = "library"
    const val SETTINGS = "settings"
    const val PLAYER_PATTERN = "player/{videoId}"
    fun player(videoId: String) = "player/$videoId"
    val all = listOf(HOME, SEARCH, LIBRARY, SETTINGS)
}

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    data object Home : Screen(Routes.HOME, "Ana Sayfa", Icons.Filled.Home)
    data object Search : Screen(Routes.SEARCH, "Ara", Icons.Filled.Search)
    data object Library : Screen(Routes.LIBRARY, "Kütüphane", Icons.Filled.VideoLibrary)
    data object Settings : Screen(Routes.SETTINGS, "Ayarlar", Icons.Filled.Settings)

    companion object {
        val bottomItems: List<Screen> by lazy { listOf(Home, Search, Library, Settings) }
    }
}
