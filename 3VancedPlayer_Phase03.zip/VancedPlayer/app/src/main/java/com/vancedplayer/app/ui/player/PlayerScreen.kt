package com.vancedplayer.app.ui.player

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import com.vancedplayer.app.data.VideoCatalog
import com.vancedplayer.app.ui.components.ChannelAvatar
import com.vancedplayer.app.ui.components.VideoCard
import com.vancedplayer.app.ui.theme.VpColors
import com.vancedplayer.app.util.Formatters

private val speedOptions = listOf(
    PlayerConstants.PlaybackRate.RATE_0_25 to "0,25x",
    PlayerConstants.PlaybackRate.RATE_0_5 to "0,5x",
    PlayerConstants.PlaybackRate.RATE_1 to "Normal",
    PlayerConstants.PlaybackRate.RATE_1_5 to "1,5x",
    PlayerConstants.PlaybackRate.RATE_2 to "2x"
)

private fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun PlayerScreen(videoId: String, onBack: () -> Unit, onOpenVideo: (String) -> Unit) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val controller = remember(videoId) { PlayerController() }
    var locked by rememberSaveable { mutableStateOf(false) }
    val video = remember(videoId) { VideoCatalog.get(videoId) }
    val related = remember(videoId) { VideoCatalog.related(videoId, 12) }

    DisposableEffect(landscape) {
        val window = activity?.window
        val insets = window?.let { WindowInsetsControllerCompat(it, it.decorView) }
        if (landscape) {
            insets?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            insets?.hide(WindowInsetsCompat.Type.systemBars())
        }
        onDispose { insets?.show(WindowInsetsCompat.Type.systemBars()) }
    }
    DisposableEffect(Unit) {
        onDispose { activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
    }

    val rotate = {
        activity?.requestedOrientation = if (landscape) {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        }
    }

    BackHandler {
        if (landscape) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            onBack()
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        Column(modifier = Modifier.fillMaxSize()) {
            PlayerBox(
                modifier = if (landscape) {
                    Modifier.fillMaxSize().padding(end = 72.dp)
                } else {
                    Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                },
                videoId = videoId,
                controller = controller,
                locked = locked,
                onUnlock = { locked = false }
            )
            if (!landscape) {
                Row(
                    modifier = Modifier.fillMaxWidth().background(VpColors.Surface).padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ControlButtons(controller, locked, onLock = { locked = true }, onRotate = rotate, onBack = onBack)
                }
                LazyColumn(
                    modifier = Modifier.fillMaxSize().background(VpColors.Black),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    item { VideoInfo(video) }
                    if (related.isNotEmpty()) {
                        item {
                            Text(
                                "Önerilen videolar",
                                color = VpColors.TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        items(related, key = { it.id }) { v ->
                            VideoCard(video = v, onClick = { onOpenVideo(v.id) })
                        }
                    }
                }
            }
        }
        if (landscape) {
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .width(72.dp)
                    .background(VpColors.Surface),
                verticalArrangement = Arrangement.SpaceEvenly,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ControlButtons(controller, locked, onLock = { locked = true }, onRotate = rotate, onBack = onBack)
            }
        }
    }
}

@Composable
private fun PlayerBox(
    modifier: Modifier,
    videoId: String,
    controller: PlayerController,
    locked: Boolean,
    onUnlock: () -> Unit
) {
    Box(modifier = modifier.background(Color.Black)) {
        YouTubePlayerSurface(videoId = videoId, controller = controller, modifier = Modifier.fillMaxSize())
        controller.errorMessage?.let { message ->
            Box(
                modifier = Modifier.fillMaxSize().background(Color(0xE6000000)).padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(message, color = Color.White, fontSize = 14.sp, textAlign = TextAlign.Center)
            }
        }
        if (locked) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {}
                    )
            )
            IconButton(
                onClick = onUnlock,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .clip(CircleShape)
                    .background(Color(0x99000000))
            ) {
                Icon(Icons.Filled.LockOpen, contentDescription = "Ekran kilidini aç", tint = Color.White)
            }
        }
    }
}

@Composable
private fun ControlButtons(
    controller: PlayerController,
    locked: Boolean,
    onLock: () -> Unit,
    onRotate: () -> Unit,
    onBack: () -> Unit
) {
    var speedMenu by remember { mutableStateOf(false) }
    val enabled = !locked
    IconButton(onClick = onBack) {
        Icon(Icons.Filled.ArrowBack, contentDescription = "Geri", tint = VpColors.TextPrimary)
    }
    IconButton(onClick = { controller.seekBy(-10f) }, enabled = enabled) {
        Icon(Icons.Filled.Replay10, contentDescription = "10 sn geri", tint = VpColors.TextPrimary)
    }
    IconButton(onClick = { controller.togglePlay() }, enabled = enabled) {
        Icon(
            if (controller.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
            contentDescription = if (controller.isPlaying) "Duraklat" else "Oynat",
            tint = VpColors.TextPrimary
        )
    }
    IconButton(onClick = { controller.seekBy(10f) }, enabled = enabled) {
        Icon(Icons.Filled.Forward10, contentDescription = "10 sn ileri", tint = VpColors.TextPrimary)
    }
    Box {
        IconButton(onClick = { speedMenu = true }, enabled = enabled) {
            Icon(
                Icons.Filled.Speed,
                contentDescription = "Oynatma hızı",
                tint = if (controller.speed == PlayerConstants.PlaybackRate.RATE_1) VpColors.TextPrimary else VpColors.Blue
            )
        }
        DropdownMenu(expanded = speedMenu, onDismissRequest = { speedMenu = false }) {
            speedOptions.forEach { (rate, label) ->
                DropdownMenuItem(
                    text = { Text(label) },
                    onClick = {
                        controller.setSpeed(rate)
                        speedMenu = false
                    }
                )
            }
        }
    }
    IconButton(onClick = onLock, enabled = enabled) {
        Icon(Icons.Filled.Lock, contentDescription = "Ekranı kilitle", tint = VpColors.TextPrimary)
    }
    IconButton(onClick = onRotate, enabled = enabled) {
        Icon(Icons.Filled.ScreenRotation, contentDescription = "Ekranı döndür", tint = VpColors.TextPrimary)
    }
}

@Composable
private fun VideoInfo(video: com.vancedplayer.app.data.model.Video?) {
    val now = remember { System.currentTimeMillis() }
    Column {
        Text(
            text = video?.title ?: "Video",
            color = VpColors.TextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
        if (video != null) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = Formatters.views(video.views) + " · " + Formatters.relative(video.publishedAt, now),
                color = VpColors.TextSecondary,
                fontSize = 13.sp
            )
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                ChannelAvatar(video.channelName)
                Spacer(Modifier.width(12.dp))
                Text(
                    text = video.channelName,
                    color = VpColors.TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
