# Vanced Player – Aşama 3 (Örnek veri, video kartları, oynatıcı)

Kotlin + Jetpack Compose + MVVM. Derleme GitHub Actions ile yapılır (README sonundaki adımlar).

## Bu aşamada eklenenler
- Örnek veri (TEST MODU): `data/sample/SampleData.kt` – gerçek YouTube video kimlikleri, yaklaşık izlenme/tarih değerleri.
- Ana ekran: kategori filtresi, yüklenme animasyonu, hata + "Tekrar dene", gerçek küçük resimler (Coil), kanal, izlenme, tarih, süre.
- Video oynatıcı (resmi YouTube IFrame, `android-youtube-player`):
  - YouTube'un kendi kontrolleri: oynat/duraklat, kalite, altyazı, ayarlar menüsü
  - Ek kontroller: 10 sn geri/ileri, oynatma hızı, ekran kilidi, ekran döndürme (yatay/dikey)
  - Yatayda tam ekran (sistem çubukları gizlenir), önerilen videolar listesi
  - Uygulama arka plana geçince oynatma durur (arka planda oynatma yoktur)
- Hata kaydı: yakalanmayan çökmeler ve yakalanan hatalar `crash.log` dosyasına yazılır (Aşama 6'da Ayarlar'dan görülecek).
- Birim testleri: biçimlendiriciler, örnek veri, rotalar.

## Bilinen sınırlar
- Örnek listede yalnızca Müzik ve Film videoları var; diğer kategoriler boş durum mesajı gösterir.
- Bazı videolar sahibi tarafından gömülü oynatmaya kapatılmış olabilir; oynatıcı bunu ekranda belirtir.
- Kalite seçimi YouTube'un kendi menüsündendir (IFrame API kaliteyi dışarıdan ayarlamaya izin vermez).
- Bu kod geliştirme ortamında derlenemedi; gerçek derleme GitHub Actions'ta yapılır.

## Telefondan APK üretme (GitHub Actions)
1. Depoda eski ZIP dosyasını silin (Delete file), yenisini yükleyin (Add file > Upload files).
2. Actions sekmesinde derleme başlar; bitince Artifacts > `VancedPlayer-debug-apk` indirin, ZIP'ten çıkan APK'yı kurun.
3. Hata olursa kırmızı adımın log'unu gönderin.
