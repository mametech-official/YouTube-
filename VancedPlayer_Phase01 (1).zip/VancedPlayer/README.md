# Vanced Player – Aşama 1 (Proje Altyapısı)

Kotlin + Jetpack Compose + Material 3 Android projesi. Bu aşamada yalnızca altyapı vardır:
Gradle (Kotlin DSL + version catalog), manifest, uygulama sınıfı, karanlık tema, uygulama simgesi,
tek bir yer tutucu ekran ve bir birim testi.

## Kurulum
1. Android Studio (Koala veya daha yenisi) kurun.
2. ZIP'i bir klasöre çıkarın.
3. Android Studio > File > Open > çıkardığınız `VancedPlayer` klasörünü seçin.
4. "Gradle Sync" tamamlanana kadar bekleyin (internet gerekir; Gradle sarmalayıcı dosyasını Studio kendisi indirir).
5. Telefonu USB ile bağlayın (Geliştirici seçenekleri > USB hata ayıklama açık) ve Run ▶ düğmesine basın.
6. APK için: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Durum
- minSdk 26 (Android 8.0), targetSdk/compileSdk 34, AGP 8.5.2, Kotlin 1.9.24, Gradle 8.7.
- Room, DataStore, ağ ve oynatıcı bağımlılıkları sonraki aşamalarda eklenecek.
- Bu aşama derlenip test EDİLEMEDİ (geliştirme ortamında internet yok).

## Telefondan APK üretme (GitHub Actions)
1. github.com'da ücretsiz hesap açın, "New repository" ile boş bir depo oluşturun.
2. Depoya bu klasörün içindekileri yükleyin ("Add file > Upload files"). `.github` klasörü de yüklenmelidir.
   (Tarayıcıdan klasör yüklemek zorsa bilgisayardan yükleyin veya GitHub Desktop kullanın.)
3. Depoda **Actions** sekmesi > **Build APK** > **Run workflow**.
4. Bitince çalışmanın içindeki **Artifacts** bölümünden `VancedPlayer-debug-apk` dosyasını indirin, ZIP'ten çıkarın, APK'yı kurun.
5. Hata olursa kırmızı adımın log'unu kopyalayıp bana gönderin.
