# Vanced Player – Aşama 5 (Kütüphane)

Kotlin + Jetpack Compose + MVVM + Room. Derleme GitHub Actions ile yapılır (README sonundaki adımlar).

## Aşama 5'te eklenenler
- Kütüphane sekmesi: Favoriler, İzleme geçmişi, Sonra izle, Abonelikler (yerel Room veritabanı).
- Oynatıcı ekranında: Favori, Sonra izle ve Abone ol düğmeleri. Video oynamaya başlayınca geçmişe kaydedilir (en fazla 200 kayıt).
- Arama > Kanallar sonuçlarında Abone ol düğmesi.
- Listelerde tek tek kaldırma ve onaylı "Listeyi temizle".
- Veritabanı sürümü 2'ye çıktı. Güncelleme sırasında geliştirme sürümünde eski arama geçmişi bir kez sıfırlanır.

## Aşama 4'te eklenenler
- Arama ekranı: video ve kanal sekmeleri, arama geçmişi (Room), geçmişten tek tek silme / tümünü temizleme, arama önerileri (geçmiş + bilinen başlıklar).
- YouTube Data API v3 (resmi): ana ekran "popüler" listesi, video araması, kanal araması. Ek kütüphane yok (HttpURLConnection + org.json).
- API anahtarı: Ara sekmesinde "API anahtarı gir". Anahtar yalnızca telefonda saklanır. Anahtar yoksa TEST MODU (örnek veri) çalışır.
- Hata durumları: kota dolu, geçersiz anahtar, ağ yok → ekranda açıklama + "Tekrar dene"; ayrıca `crash.log`'a yazılır.
- Room veritabanı (şimdilik yalnızca arama geçmişi). Sonraki aşamada tablolar eklenince geliştirme sürümünde veritabanı sıfırlanabilir.

## API anahtarı nasıl alınır
Google Cloud Console > yeni proje > "YouTube Data API v3"ü etkinleştir > Kimlik bilgileri > API anahtarı oluştur.
Anahtarı uygulama/IP ile kısıtlarsanız istekler reddedilebilir; kısıtsız anahtar kullanın ve paylaşmayın. Günlük ücretsiz kota sınırlıdır (bir arama ≈ 100 birim).

## Aşama 3'te eklenenlerin özeti
Örnek veri, video kartları, resmi YouTube IFrame oynatıcı (10 sn ileri/geri, hız, ekran kilidi, yatay tam ekran), hata kaydı.

## Bilinen sınırlar
- Kod geliştirme ortamında derlenemedi; gerçek derleme GitHub Actions'ta yapılır.
- Kalite seçimi YouTube'un kendi menüsündendir. Arka planda oynatma ve reklam engelleme yoktur (YouTube kurallarına aykırı).
- Abonelikler yalnızca yerel listedir (YouTube hesabıyla senkronize olmaz). Ana ekranda kart menüsü yok; favori/sonra izle oynatıcı ekranından yapılır.

## Telefondan APK üretme (GitHub Actions)
1. Depoda eski ZIP dosyasını silin (Delete file), yenisini yükleyin (Add file > Upload files).
2. Actions sekmesinde derleme başlar; bitince Artifacts > `VancedPlayer-debug-apk` indirin, ZIP'ten çıkan APK'yı kurun.
3. Hata olursa kırmızı adımın log'unu gönderin.
