package com.vancedplayer.app

import android.content.Context
import com.vancedplayer.app.data.local.AppDatabase
import com.vancedplayer.app.data.prefs.AppPrefs
import com.vancedplayer.app.data.repo.AppRepository
import com.vancedplayer.app.data.repo.LibraryRepository
import com.vancedplayer.app.data.repo.VideoRepository

/** Uygulama genelinde paylaşılan bağımlılıklar (basit el ile bağımlılık enjeksiyonu). */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    val prefs = AppPrefs(appContext)
    val db: AppDatabase by lazy { AppDatabase.build(appContext) }
    val repository: VideoRepository = AppRepository(prefs)
    val library: LibraryRepository by lazy { LibraryRepository(db.libraryDao()) }
}
