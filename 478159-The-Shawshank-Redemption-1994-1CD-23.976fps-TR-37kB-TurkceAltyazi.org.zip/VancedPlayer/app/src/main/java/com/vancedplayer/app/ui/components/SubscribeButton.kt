package com.vancedplayer.app.ui.components

import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import com.vancedplayer.app.ui.theme.VpColors

@Composable
fun SubscribeButton(subscribed: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Button(
        onClick = onClick,
        modifier = modifier,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (subscribed) VpColors.Card else Color.White,
            contentColor = if (subscribed) VpColors.TextPrimary else Color.Black
        )
    ) {
        Text(if (subscribed) "Abonesin" else "Abone ol", fontSize = 13.sp)
    }
}
