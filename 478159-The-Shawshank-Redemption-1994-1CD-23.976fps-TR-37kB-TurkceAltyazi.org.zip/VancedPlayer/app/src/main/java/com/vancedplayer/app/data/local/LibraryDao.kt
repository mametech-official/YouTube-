package com.vancedplayer.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LibraryDao {
    @Query("SELECT * FROM saved_videos WHERE listType = :type ORDER BY addedAt DESC")
    fun observe(type: String): Flow<List<SavedVideo>>

    @Query("SELECT EXISTS(SELECT 1 FROM saved_videos WHERE videoId = :id AND listType = :type)")
    fun observeContains(id: String, type: String): Flow<Boolean>

    @Query("SELECT EXISTS(SELECT 1 FROM saved_videos WHERE videoId = :id AND listType = :type)")
    suspend fun contains(id: String, type: String): Boolean

    @Query("SELECT COUNT(*) FROM saved_videos WHERE listType = :type")
    fun observeCount(type: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(video: SavedVideo)

    @Query("DELETE FROM saved_videos WHERE videoId = :id AND listType = :type")
    suspend fun remove(id: String, type: String)

    @Query("DELETE FROM saved_videos WHERE listType = :type")
    suspend fun clear(type: String)

    @Query(
        "DELETE FROM saved_videos WHERE listType = :type AND videoId NOT IN " +
            "(SELECT videoId FROM saved_videos WHERE listType = :type ORDER BY addedAt DESC LIMIT :keep)"
    )
    suspend fun trim(type: String, keep: Int)

    @Query("SELECT * FROM subscriptions ORDER BY addedAt DESC")
    fun observeSubscriptions(): Flow<List<SubscriptionEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM subscriptions WHERE channelId = :id)")
    fun observeSubscribed(id: String): Flow<Boolean>

    @Query("SELECT EXISTS(SELECT 1 FROM subscriptions WHERE channelId = :id)")
    suspend fun isSubscribed(id: String): Boolean

    @Query("SELECT COUNT(*) FROM subscriptions")
    fun observeSubscriptionCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun subscribe(entity: SubscriptionEntity)

    @Query("DELETE FROM subscriptions WHERE channelId = :id")
    suspend fun unsubscribe(id: String)

    @Query("DELETE FROM subscriptions")
    suspend fun clearSubscriptions()
}
