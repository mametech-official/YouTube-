package com.vancedplayer.app

import android.app.Application
import com.vancedplayer.app.util.CrashLogger

class VancedPlayerApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        CrashLogger.install(this)
        container = AppContainer(this)
    }
}
