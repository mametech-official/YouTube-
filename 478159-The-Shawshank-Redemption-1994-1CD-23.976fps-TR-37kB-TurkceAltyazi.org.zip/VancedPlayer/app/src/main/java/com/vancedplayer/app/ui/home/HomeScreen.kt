package com.vancedplayer.app.ui.home

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vancedplayer.app.data.model.Categories
import com.vancedplayer.app.ui.components.SkeletonVideoCard
import com.vancedplayer.app.ui.components.VideoCard
import com.vancedplayer.app.ui.components.rememberShimmerBrush
import com.vancedplayer.app.ui.theme.BrandBrush
import com.vancedplayer.app.ui.theme.VpColors

@Composable
fun HomeScreen(onSearchClick: () -> Unit, onVideoClick: (String) -> Unit) {
    val vm: HomeViewModel = viewModel()
    val state by vm.state.collectAsState()
    val shimmer = rememberShimmerBrush()
    LaunchedEffect(Unit) { vm.refreshIfModeChanged() }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item { BrandHeader() }
        item { SearchBarPlaceholder(onClick = onSearchClick) }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(Categories.all) { index, category ->
                    CategoryChip(
                        text = category.label,
                        selected = index == state.categoryIndex,
                        onClick = { vm.selectCategory(index) }
                    )
                }
            }
        }
        if (state.sampleMode) {
            item {
                Text(
                    text = "Test modu: örnek veriler gösteriliyor. Gerçek içerik için Ara sekmesinden API anahtarı girin.",
                    color = VpColors.TextSecondary,
                    fontSize = 12.sp
                )
            }
        }
        when {
            state.loading -> items(3) { SkeletonVideoCard(shimmer) }
            state.error != null -> item {
                MessageBlock(
                    text = "Videolar yüklenemedi: ${state.error}",
                    actionLabel = "Tekrar dene",
                    onAction = { vm.load() }
                )
            }
            state.videos.isEmpty() -> item {
                MessageBlock(
                    text = if (state.sampleMode) "Bu kategoride örnek video yok. Gerçek içerik için Ara sekmesinden API anahtarı girin." else "Bu kategoride video bulunamadı.",
                    actionLabel = null,
                    onAction = {}
                )
            }
            else -> items(state.videos, key = { it.id }) { video ->
                VideoCard(video = video, onClick = { onVideoClick(video.id) })
            }
        }
    }
}

@Composable
private fun MessageBlock(text: String, actionLabel: String?, onAction: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text, color = VpColors.TextSecondary, fontSize = 14.sp, textAlign = TextAlign.Center)
        if (actionLabel != null) {
            Spacer(Modifier.height(12.dp))
            Button(onClick = onAction) { Text(actionLabel) }
        }
    }
}

@Composable
private fun BrandHeader() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(BrandBrush),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.White)
        }
        Spacer(Modifier.width(10.dp))
        Text(
            text = "Vanced Player",
            style = TextStyle(brush = BrandBrush, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        )
    }
}

@Composable
private fun SearchBarPlaceholder(onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(VpColors.Card)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Search, contentDescription = null, tint = VpColors.TextSecondary)
        Spacer(Modifier.width(12.dp))
        Text("Video veya kanal ara", color = VpColors.TextSecondary, fontSize = 15.sp)
    }
}

@Composable
private fun CategoryChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val textColor by animateColorAsState(
        targetValue = if (selected) Color.White else VpColors.TextSecondary,
        label = "chipText"
    )
    val background = if (selected) Modifier.background(BrandBrush) else Modifier.background(VpColors.Card)
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .then(background)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(text, color = textColor, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}
