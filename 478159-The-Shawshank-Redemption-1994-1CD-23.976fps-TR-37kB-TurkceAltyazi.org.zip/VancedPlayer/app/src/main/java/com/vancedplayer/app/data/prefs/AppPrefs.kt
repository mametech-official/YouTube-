package com.vancedplayer.app.data.prefs

import android.content.Context

/** Basit yerel ayarlar (SharedPreferences). */
class AppPrefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("vp_prefs", Context.MODE_PRIVATE)

    /** Kullanıcının kendi YouTube Data API v3 anahtarı. Boşsa örnek veri modu kullanılır. */
    var apiKey: String
        get() = sp.getString(KEY_API, "") ?: ""
        set(value) {
            sp.edit().putString(KEY_API, value.trim()).apply()
        }

    /** Anahtar olsa bile örnek verileri kullan (test modu). */
    var forceSample: Boolean
        get() = sp.getBoolean(KEY_FORCE_SAMPLE, false)
        set(value) {
            sp.edit().putBoolean(KEY_FORCE_SAMPLE, value).apply()
        }

    private companion object {
        const val KEY_API = "api_key"
        const val KEY_FORCE_SAMPLE = "force_sample"
    }
}
