package com.vancedplayer.app.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vancedplayer.app.VancedPlayerApp
import com.vancedplayer.app.data.model.Categories
import com.vancedplayer.app.data.model.Video
import com.vancedplayer.app.util.CrashLogger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class HomeViewModel(app: Application) : AndroidViewModel(app) {

    data class UiState(
        val loading: Boolean = true,
        val videos: List<Video> = emptyList(),
        val error: String? = null,
        val categoryIndex: Int = 0,
        val sampleMode: Boolean = true
    )

    private val repo = (app as VancedPlayerApp).container.repository
    private val _state = MutableStateFlow(UiState(sampleMode = repo.isSampleData()))
    val state: StateFlow<UiState> = _state.asStateFlow()
    private var job: Job? = null

    init {
        load()
    }

    fun selectCategory(index: Int) {
        if (index == _state.value.categoryIndex) return
        _state.update { it.copy(categoryIndex = index) }
        load()
    }

    /** Ayarlarda API anahtarı / test modu değiştiyse listeyi yeniler. */
    fun refreshIfModeChanged() {
        if (repo.isSampleData() != _state.value.sampleMode) load()
    }

    fun load() {
        job?.cancel()
        val category = Categories.all[_state.value.categoryIndex]
        job = viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null, sampleMode = repo.isSampleData()) }
            try {
                val list = repo.home(category)
                _state.update { it.copy(loading = false, videos = list) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CrashLogger.logHandled("Ana ekran yüklenemedi", e)
                _state.update { it.copy(loading = false, error = e.message ?: "Bilinmeyen hata") }
            }
        }
    }
}
