package com.vancedplayer.app.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.navArgument
import com.vancedplayer.app.ui.player.PlayerScreen
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.vancedplayer.app.ui.home.HomeScreen
import com.vancedplayer.app.ui.library.LibraryScreen
import com.vancedplayer.app.ui.screens.ComingSoonScreen
import com.vancedplayer.app.ui.search.SearchScreen
import com.vancedplayer.app.ui.theme.VpColors

private fun NavController.navigateTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun MainScreen() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination
    val isPlayer = currentDestination?.route == Routes.PLAYER_PATTERN

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (!isPlayer) NavigationBar(containerColor = VpColors.Surface) {
                Screen.bottomItems.forEach { screen ->
                    val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = { navController.navigateTab(screen.route) },
                        icon = { Icon(screen.icon, contentDescription = screen.label) },
                        label = { Text(screen.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = Color.White,
                            indicatorColor = VpColors.Purple.copy(alpha = 0.40f),
                            unselectedIconColor = VpColors.TextSecondary,
                            unselectedTextColor = VpColors.TextSecondary
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.HOME,
            modifier = Modifier.padding(innerPadding).then(if (isPlayer) Modifier else Modifier.statusBarsPadding()),
            enterTransition = { fadeIn(tween(250)) },
            exitTransition = { fadeOut(tween(200)) },
            popEnterTransition = { fadeIn(tween(250)) },
            popExitTransition = { fadeOut(tween(200)) }
        ) {
            composable(Routes.HOME) {
                HomeScreen(
                    onSearchClick = { navController.navigateTab(Routes.SEARCH) },
                    onVideoClick = { id -> navController.navigate(Routes.player(id)) }
                )
            }
            composable(
                route = Routes.PLAYER_PATTERN,
                arguments = listOf(navArgument("videoId") { type = NavType.StringType })
            ) { entry ->
                val videoId = entry.arguments?.getString("videoId").orEmpty()
                PlayerScreen(
                    videoId = videoId,
                    onBack = { navController.popBackStack() },
                    onOpenVideo = { id ->
                        navController.navigate(Routes.player(id)) {
                            popUpTo(Routes.PLAYER_PATTERN) { inclusive = true }
                        }
                    }
                )
            }
            composable(Routes.SEARCH) {
                SearchScreen(onVideoClick = { id -> navController.navigate(Routes.player(id)) })
            }
            composable(Routes.LIBRARY) {
                LibraryScreen(onVideoClick = { id -> navController.navigate(Routes.player(id)) })
            }
            composable(Routes.SETTINGS) {
                ComingSoonScreen(Screen.Settings.icon, "Ayarlar", "Ayarlar Aşama 6'da eklenecek.")
            }
        }
    }
}
