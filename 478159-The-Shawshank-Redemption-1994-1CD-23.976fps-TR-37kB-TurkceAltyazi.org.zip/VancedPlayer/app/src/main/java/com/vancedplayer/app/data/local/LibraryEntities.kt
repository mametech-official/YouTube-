package com.vancedplayer.app.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

object ListType {
    const val FAVORITE = "favorite"
    const val LATER = "later"
    const val HISTORY = "history"
}

/** Favoriler, "daha sonra izle" ve izleme geçmişi aynı tabloda, listType ile ayrılır. */
@Entity(
    tableName = "saved_videos",
    primaryKeys = ["videoId", "listType"],
    indices = [Index("listType", "addedAt")]
)
data class SavedVideo(
    val videoId: String,
    val listType: String,
    val title: String,
    val channelId: String,
    val channelName: String,
    val category: String,
    val views: Long,
    val publishedAt: Long,
    val durationSec: Int,
    val addedAt: Long
)

@Entity(tableName = "subscriptions")
data class SubscriptionEntity(
    @PrimaryKey val channelId: String,
    val name: String,
    val thumbnailUrl: String?,
    val subscribers: Long?,
    val description: String,
    val addedAt: Long
)
