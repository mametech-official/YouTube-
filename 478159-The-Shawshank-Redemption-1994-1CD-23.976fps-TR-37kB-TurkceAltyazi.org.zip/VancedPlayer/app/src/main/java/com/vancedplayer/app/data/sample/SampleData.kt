package com.vancedplayer.app.data.sample

import com.vancedplayer.app.data.model.ChannelItem
import com.vancedplayer.app.data.model.Video

/**
 * TEST MODU örnek verileri. Video kimlikleri gerçek YouTube videolarına aittir (resmi oynatıcıyla açılır),
 * ancak izlenme sayıları ve tarihler yaklaşık/örnek değerlerdir.
 */
object SampleData {
    private const val DAY = 86_400_000L

    private data class Row(
        val id: String,
        val title: String,
        val channel: String,
        val category: String,
        val views: Long,
        val daysAgo: Int,
        val durationSec: Int
    )

    private val rows = listOf(
        Row("dQw4w9WgXcQ", "Rick Astley - Never Gonna Give You Up (Official Video)", "Rick Astley", "Müzik", 1_600_000_000, 5800, 213),
        Row("aqz-KE-bpKQ", "Big Buck Bunny 60fps 4K - Official Blender Foundation Short Film", "Blender", "Film", 60_000_000, 4300, 635),
        Row("9bZkp7q19f0", "PSY - GANGNAM STYLE(강남스타일) M/V", "PSY", "Müzik", 5_500_000_000, 5200, 253),
        Row("kJQP7kiw5Fk", "Luis Fonsi - Despacito ft. Daddy Yankee", "Luis Fonsi", "Müzik", 8_500_000_000, 3400, 282),
        Row("eRsGyueVLvQ", "Sintel - Open Movie by Blender Foundation", "Blender", "Film", 20_000_000, 5800, 888),
        Row("JGwWNGJdvx8", "Ed Sheeran - Shape of You (Official Music Video)", "Ed Sheeran", "Müzik", 6_200_000_000, 3600, 264),
        Row("fJ9rUzIMcZQ", "Queen - Bohemian Rhapsody (Official Video Remastered)", "Queen Official", "Müzik", 1_900_000_000, 6000, 359),
        Row("R6MlUcmOul8", "Tears of Steel", "Blender", "Film", 6_000_000, 5200, 734),
        Row("OPf0YbXqDm0", "Mark Ronson - Uptown Funk (Official Video) ft. Bruno Mars", "Mark Ronson", "Müzik", 5_000_000_000, 4300, 270),
        Row("jNQXAC9IALk", "Me at the zoo", "jawed", "Genel", 360_000_000, 7500, 19)
    )

    fun channelIdOf(name: String): String = "sample_" + name.lowercase().replace(" ", "")

    fun videos(now: Long = System.currentTimeMillis()): List<Video> = rows.map {
        Video(
            id = it.id,
            title = it.title,
            channelId = channelIdOf(it.channel),
            channelName = it.channel,
            category = it.category,
            views = it.views,
            publishedAt = now - it.daysAgo * DAY,
            durationSec = it.durationSec
        )
    }

    fun channels(): List<ChannelItem> = listOf(
        ChannelItem(channelIdOf("Rick Astley"), "Rick Astley", 12_000_000, null, "Örnek kanal: müzik"),
        ChannelItem(channelIdOf("PSY"), "PSY", 18_000_000, null, "Örnek kanal: müzik"),
        ChannelItem(channelIdOf("Luis Fonsi"), "Luis Fonsi", 20_000_000, null, "Örnek kanal: müzik"),
        ChannelItem(channelIdOf("Ed Sheeran"), "Ed Sheeran", 58_000_000, null, "Örnek kanal: müzik"),
        ChannelItem(channelIdOf("Queen Official"), "Queen Official", 20_000_000, null, "Örnek kanal: müzik"),
        ChannelItem(channelIdOf("Mark Ronson"), "Mark Ronson", 3_000_000, null, "Örnek kanal: müzik"),
        ChannelItem(channelIdOf("Blender"), "Blender", 1_000_000, null, "Örnek kanal: açık kaynak kısa filmler"),
        ChannelItem(channelIdOf("jawed"), "jawed", 3_000_000, null, "Örnek kanal: genel")
    )
}
