package com.vancedplayer.app.util

object Suggestions {
    /** Arama önerileri: önce geçmiş, sonra bilinen video/kanal başlıkları. */
    fun build(query: String, history: List<String>, titles: List<String>, limit: Int = 8): List<String> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()
        val fromHistory = history.filter { it.lowercase().contains(q) }
        val fromTitles = titles.filter { it.lowercase().contains(q) }
        return (fromHistory + fromTitles).distinct().take(limit)
    }
}
