package com.vancedplayer.app

import com.vancedplayer.app.data.local.ListType
import com.vancedplayer.app.data.model.ChannelItem
import com.vancedplayer.app.data.model.Video
import com.vancedplayer.app.data.repo.toEntity
import com.vancedplayer.app.data.repo.toItem
import com.vancedplayer.app.data.repo.toSaved
import com.vancedplayer.app.data.repo.toVideo
import org.junit.Assert.assertEquals
import org.junit.Test

class LibraryMappingTest {
    @Test
    fun videoRoundTripsThroughSavedVideo() {
        val v = Video("abcdefghijk", "Başlık", "ch1", "Kanal", "Müzik", 10L, 20L, 30)
        val saved = v.toSaved(ListType.FAVORITE, 99L)
        assertEquals(ListType.FAVORITE, saved.listType)
        assertEquals(99L, saved.addedAt)
        assertEquals(v, saved.toVideo())
    }

    @Test
    fun channelRoundTripsThroughEntity() {
        val c = ChannelItem("c1", "Kanal", 5L, "https://x/y.jpg", "açıklama")
        assertEquals(c, c.toEntity(1L).toItem())
    }
}
