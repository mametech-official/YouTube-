package com.vancedplayer.app.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavController
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.vancedplayer.app.ui.home.HomeScreen
import com.vancedplayer.app.ui.screens.ComingSoonScreen
import com.vancedplayer.app.ui.theme.VpColors

private fun NavController.navigateTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun MainScreen() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = VpColors.Surface) {
                Screen.bottomItems.forEach { screen ->
                    val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = { navController.navigateTab(screen.route) },
                        icon = { Icon(screen.icon, contentDescription = screen.label) },
                        label = { Text(screen.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = Color.White,
                            indicatorColor = VpColors.Purple.copy(alpha = 0.40f),
                            unselectedIconColor = VpColors.TextSecondary,
                            unselectedTextColor = VpColors.TextSecondary
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.HOME,
            modifier = Modifier.padding(innerPadding).statusBarsPadding(),
            enterTransition = { fadeIn(tween(250)) },
            exitTransition = { fadeOut(tween(200)) },
            popEnterTransition = { fadeIn(tween(250)) },
            popExitTransition = { fadeOut(tween(200)) }
        ) {
            composable(Routes.HOME) {
                HomeScreen(onSearchClick = { navController.navigateTab(Routes.SEARCH) })
            }
            composable(Routes.SEARCH) {
                ComingSoonScreen(Screen.Search.icon, "Arama", "Video ve kanal arama Aşama 4'te eklenecek.")
            }
            composable(Routes.LIBRARY) {
                ComingSoonScreen(Screen.Library.icon, "Kütüphane", "Favoriler, geçmiş ve abonelikler Aşama 5'te eklenecek.")
            }
            composable(Routes.SETTINGS) {
                ComingSoonScreen(Screen.Settings.icon, "Ayarlar", "Ayarlar Aşama 6'da eklenecek.")
            }
        }
    }
}
