package com.vancedplayer.app.ui.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.vancedplayer.app.MainActivity

/**
 * Video oynarken çalışan ön plan servisi. Ekran kapanınca veya uygulamadan çıkılınca
 * Android'in uygulamayı sonlandırmasını önler; sesin kesilmeden devam etmesini sağlar.
 */
class PlaybackService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val title = intent?.getStringExtra(EXTRA_TITLE).orEmpty().ifBlank { "Vanced Player" }
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification: Notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText("Vanced Player oynatıyor")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        return START_NOT_STICKY
    }

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Oynatma", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    companion object {
        private const val CHANNEL_ID = "vp_playback"
        private const val NOTIFICATION_ID = 1001
        private const val EXTRA_TITLE = "title"

        fun start(context: Context, title: String) {
            try {
                val intent = Intent(context, PlaybackService::class.java).putExtra(EXTRA_TITLE, title)
                ContextCompat.startForegroundService(context, intent)
            } catch (e: Exception) {
                com.vancedplayer.app.util.CrashLogger.logHandled("Oynatma servisi başlatılamadı", e)
            }
        }

        fun stop(context: Context) {
            try {
                context.stopService(Intent(context, PlaybackService::class.java))
            } catch (e: Exception) {
                com.vancedplayer.app.util.CrashLogger.logHandled("Oynatma servisi durdurulamadı", e)
            }
        }
    }
}
