package com.vancedplayer.app.ui.player

import androidx.compose.runtime.compositionLocalOf

/** Oynatıcı ekranının durumu; MainActivity küçük pencereye (PiP) geçip geçmeyeceğine buna bakar. */
object PlaybackSession {
    @Volatile
    var playerVisible: Boolean = false

    @Volatile
    var playing: Boolean = false
}

/** Aktivite küçük pencere (PiP) modunda mı? */
val LocalPipMode = compositionLocalOf { false }
