package com.vancedplayer.app.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vancedplayer.app.VancedPlayerApp
import com.vancedplayer.app.data.local.ListType
import com.vancedplayer.app.ui.components.ApiKeyDialog
import com.vancedplayer.app.ui.components.ChannelAvatar
import com.vancedplayer.app.ui.components.ConfirmDialog
import com.vancedplayer.app.ui.theme.VpColors
import com.vancedplayer.app.util.CrashLogger
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val container = remember(context) { (context.applicationContext as VancedPlayerApp).container }
    val prefs = container.prefs
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    var name by remember { mutableStateOf(prefs.profileName) }
    var email by remember { mutableStateOf(prefs.profileEmail) }
    var apiKey by remember { mutableStateOf(prefs.apiKey) }
    var forceSample by remember { mutableStateOf(prefs.forceSample) }
    var backgroundPlay by remember { mutableStateOf(prefs.backgroundPlay) }
    var pip by remember { mutableStateOf(prefs.pipEnabled) }

    var showProfile by remember { mutableStateOf(false) }
    var showApi by remember { mutableStateOf(false) }
    var showLog by remember { mutableStateOf(false) }
    var confirmHistory by remember { mutableStateOf(false) }
    var logText by remember { mutableStateOf("") }

    val favorites by container.library.count(ListType.FAVORITE).collectAsState(initial = 0)
    val history by container.library.count(ListType.HISTORY).collectAsState(initial = 0)
    val later by container.library.count(ListType.LATER).collectAsState(initial = 0)
    val subs by container.library.subscriptionCount().collectAsState(initial = 0)

    val versionName = remember(context) {
        try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "1.0.0"
        } catch (_: Exception) {
            "1.0.0"
        }
    }

    if (showProfile) {
        ProfileDialog(
            initialName = name,
            initialEmail = email,
            onSave = { n, e ->
                prefs.profileName = n
                prefs.profileEmail = e
                name = prefs.profileName
                email = prefs.profileEmail
                showProfile = false
            },
            onRemove = {
                prefs.profileName = ""
                prefs.profileEmail = ""
                name = ""
                email = ""
                showProfile = false
            },
            onDismiss = { showProfile = false }
        )
    }
    if (showApi) {
        ApiKeyDialog(
            currentKey = apiKey,
            onSave = { key ->
                prefs.apiKey = key
                apiKey = prefs.apiKey
                showApi = false
            },
            onDismiss = { showApi = false }
        )
    }
    if (confirmHistory) {
        ConfirmDialog(
            title = "Geçmişi temizle",
            message = "İzleme geçmişindeki tüm videolar silinecek. Emin misiniz?",
            confirmLabel = "Temizle",
            onConfirm = {
                scope.launch {
                    try {
                        container.library.clear(ListType.HISTORY)
                    } catch (e: Exception) {
                        CrashLogger.logHandled("Geçmiş temizlenemedi", e)
                    }
                }
                confirmHistory = false
            },
            onDismiss = { confirmHistory = false }
        )
    }
    if (showLog) {
        AlertDialog(
            onDismissRequest = { showLog = false },
            title = { Text("Hata kaydı") },
            text = {
                Box(modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                    Text(
                        text = logText.ifBlank { "Kayıtlı hata yok." },
                        color = VpColors.TextSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showLog = false }) { Text("Kapat") } },
            dismissButton = {
                Row {
                    if (logText.isNotBlank()) {
                        TextButton(onClick = { clipboard.setText(AnnotatedString(logText)) }) { Text("Kopyala") }
                        TextButton(onClick = {
                            CrashLogger.clear()
                            logText = ""
                        }) { Text("Temizle") }
                    }
                }
            }
        )
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)
    ) {
        Text(
            text = "Hesap ve ayarlar",
            color = VpColors.TextPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp)
        )

        // Profil kartı
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(VpColors.Card)
                .clickable { showProfile = true }
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (name.isBlank()) {
                Icon(Icons.Filled.AccountCircle, contentDescription = null, tint = VpColors.TextSecondary, modifier = Modifier.width(56.dp).height(56.dp))
            } else {
                ChannelAvatar(name, size = 56.dp)
            }
            Spacer(Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (name.isBlank()) "Hesap ekle" else name,
                    color = VpColors.TextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = if (name.isBlank()) "Adınızı girerek profil oluşturun" else email.ifBlank { "E-posta eklenmedi" },
                    color = VpColors.TextSecondary,
                    fontSize = 13.sp
                )
            }
            Text(if (name.isBlank()) "Ekle" else "Düzenle", color = VpColors.Blue, fontSize = 14.sp)
        }
        Text(
            text = "Profil yalnızca bu telefonda saklanır; Google veya YouTube hesabınıza bağlanmaz. " +
                "Favoriler, geçmiş ve abonelikler de bu telefonda tutulur.",
            color = VpColors.TextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
        )

        // İstatistikler
        Row(
            modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatBox("Favori", favorites, Modifier.weight(1f))
            StatBox("Geçmiş", history, Modifier.weight(1f))
            StatBox("Sonra izle", later, Modifier.weight(1f))
            StatBox("Abonelik", subs, Modifier.weight(1f))
        }

        SectionTitle("Oynatma")
        ToggleRow(
            title = "Arka planda oynat",
            subtitle = "Ekran kapanınca veya uygulamadan çıkınca oynatma devam eder",
            checked = backgroundPlay,
            onChange = {
                backgroundPlay = it
                prefs.backgroundPlay = it
            }
        )
        ToggleRow(
            title = "Küçük pencere (PiP)",
            subtitle = "Video oynarken ana ekrana çıkınca küçük pencerede devam eder",
            checked = pip,
            onChange = {
                pip = it
                prefs.pipEnabled = it
            }
        )
        Text(
            text = "Değişiklikler bir sonraki açılan videoda geçerli olur.",
            color = VpColors.TextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )

        SectionTitle("Veri")
        ClickRow(
            title = "YouTube API anahtarı",
            subtitle = if (apiKey.isBlank()) "Girilmedi (örnek veriler kullanılır)" else "Kayıtlı",
            onClick = { showApi = true }
        )
        ToggleRow(
            title = "Test modu",
            subtitle = "Anahtar olsa bile örnek verileri göster",
            checked = forceSample,
            onChange = {
                forceSample = it
                prefs.forceSample = it
            }
        )
        ClickRow(
            title = "İzleme geçmişini temizle",
            subtitle = "$history video",
            onClick = { confirmHistory = true }
        )

        SectionTitle("Destek")
        ClickRow(
            title = "Hata kaydı",
            subtitle = "Uygulama bir sorun yaşadıysa buradan görüp kopyalayabilirsiniz",
            onClick = {
                logText = CrashLogger.read()
                showLog = true
            }
        )
        ClickRow(title = "Sürüm", subtitle = "Vanced Player $versionName", onClick = {})
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        color = VpColors.Blue,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 16.dp, top = 22.dp, bottom = 4.dp)
    )
}

@Composable
private fun StatBox(label: String, value: Int, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(VpColors.Card)
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value.toString(), color = VpColors.TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(label, color = VpColors.TextSecondary, fontSize = 11.sp)
    }
}

@Composable
private fun ToggleRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = VpColors.TextPrimary, fontSize = 15.sp)
            Text(subtitle, color = VpColors.TextSecondary, fontSize = 12.sp)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ClickRow(title: String, subtitle: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(title, color = VpColors.TextPrimary, fontSize = 15.sp)
        Text(subtitle, color = VpColors.TextSecondary, fontSize = 12.sp)
    }
}

@Composable
private fun ProfileDialog(
    initialName: String,
    initialEmail: String,
    onSave: (String, String) -> Unit,
    onRemove: () -> Unit,
    onDismiss: () -> Unit
) {
    var n by remember { mutableStateOf(initialName) }
    var e by remember { mutableStateOf(initialEmail) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialName.isBlank()) "Hesap ekle" else "Hesabı düzenle") },
        text = {
            Column {
                TextField(
                    value = n,
                    onValueChange = { n = it },
                    singleLine = true,
                    label = { Text("Ad") }
                )
                Spacer(Modifier.height(8.dp))
                TextField(
                    value = e,
                    onValueChange = { e = it },
                    singleLine = true,
                    label = { Text("E-posta (isteğe bağlı)") }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(n.trim(), e.trim()) }, enabled = n.isNotBlank()) { Text("Kaydet") }
        },
        dismissButton = {
            Row {
                if (initialName.isNotBlank()) {
                    TextButton(onClick = onRemove) { Text("Hesabı kaldır") }
                }
                TextButton(onClick = onDismiss) { Text("İptal") }
            }
        }
    )
}
