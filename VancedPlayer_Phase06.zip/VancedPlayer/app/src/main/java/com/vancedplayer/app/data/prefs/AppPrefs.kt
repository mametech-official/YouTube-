package com.vancedplayer.app.data.prefs

import android.content.Context

/** Basit yerel ayarlar (SharedPreferences). */
class AppPrefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("vp_prefs", Context.MODE_PRIVATE)

    /** Kullanıcının kendi YouTube Data API v3 anahtarı. Boşsa örnek veri modu kullanılır. */
    var apiKey: String
        get() = sp.getString(KEY_API, "") ?: ""
        set(value) {
            sp.edit().putString(KEY_API, value.trim()).apply()
        }

    /** Anahtar olsa bile örnek verileri kullan (test modu). */
    var forceSample: Boolean
        get() = sp.getBoolean(KEY_FORCE_SAMPLE, false)
        set(value) {
            sp.edit().putBoolean(KEY_FORCE_SAMPLE, value).apply()
        }

    /** Uygulamadan çıkınca / ekran kapanınca oynatmaya devam et. */
    var backgroundPlay: Boolean
        get() = sp.getBoolean(KEY_BG_PLAY, true)
        set(value) {
            sp.edit().putBoolean(KEY_BG_PLAY, value).apply()
        }

    /** Ana ekrana çıkınca küçük pencerede (PiP) oynat. */
    var pipEnabled: Boolean
        get() = sp.getBoolean(KEY_PIP, true)
        set(value) {
            sp.edit().putBoolean(KEY_PIP, value).apply()
        }

    /** Yerel profil adı (boşsa hesap eklenmemiş). Yalnızca bu telefonda saklanır. */
    var profileName: String
        get() = sp.getString(KEY_PROFILE_NAME, "") ?: ""
        set(value) {
            sp.edit().putString(KEY_PROFILE_NAME, value.trim()).apply()
        }

    var profileEmail: String
        get() = sp.getString(KEY_PROFILE_EMAIL, "") ?: ""
        set(value) {
            sp.edit().putString(KEY_PROFILE_EMAIL, value.trim()).apply()
        }

    private companion object {
        const val KEY_API = "api_key"
        const val KEY_FORCE_SAMPLE = "force_sample"
        const val KEY_BG_PLAY = "background_play"
        const val KEY_PIP = "pip_enabled"
        const val KEY_PROFILE_NAME = "profile_name"
        const val KEY_PROFILE_EMAIL = "profile_email"
    }
}
